# SIATRanking

This project is about to implement Wei Cheng' KDD 2016 paper:

Cheng, Wei, et al. "Ranking causal anomalies via temporal and dynamical 
analysis on vanishing correlations." Proceedings of the 22nd ACM SIGKDD 
International Conference on Knowledge Discovery and Data Mining. ACM, 2016.

