# -*- coding: utf-8 -*-

"""
Ranking of SIAT reported sensors.

author: shuchu@nec-labs.com
"""

import sys
import numpy as np
from scipy.sparse import coo_matrix


class SIATRanking(object):
    def __init__(self):
        pass

    def calc_affinity_matrix(self, W):
        """ Calculate the affinity matrix of W.

        Args:
            W -- numpy array, each row is a sample, and each column is feature.

        Return:
            A  -- the similarity matrix.
            A1 -- the graph Laplacian.
        """

        W = np.array(W)  # Make sure it is a np array

        N = W.shape[0]

        W_mean = np.mean(W, axis=0)
        W = W - W_mean

        W_var = 2.0*np.var(W, axis=0, ddof=1)  # Variance of whole matrix
        A = np.zeros((N, N))
        for i in range(N):
            for j in range(i+1, N):
                A[i,j] = np.exp(-np.sum((W[i,:] - W[j,:])**2/W_var))
                A[j,i] = A[i,j]

        # Calculate the Graph Lablacian
        D = np.sum(A, axis=0)
        D_norm = np.diag(D**(-1/2))

        A1 = D_norm@A@D_norm

        return A, A1

    @staticmethod
    def laplacian_normlized(W: np.array):
        """
        Normalize input sparse matrix using symmetric normalized Laplacian

        Notes
        ----------
        Assuming W is symmetric, this can be achieved by .preprocess method.
        This function does not check is W has been transformed to be symmetric

        Parameters
        ----------
        W: numpy.array. Numpy ndarray

        Returns
        -------
        numpy.ndarray. Normalized ndarray

        """
        W = np.array(W)

        D = np.sum(W, axis=0)
        D_norm = np.diag(D**(-1/2))

        A1 = D_norm@W@D_norm

        return A1

    @staticmethod
    def preprocess(spa_mat: coo_matrix, output_binary: bool = False):
        """
        Preprocess input matrix.

        Notes
        ----------


        Parameters
        ----------
        spa_mat: coo_matrix. Sparse matrix

        Returns
        -------
        numpy.ndarray. Binary matrix.

        """
        assert isinstance(spa_mat, coo_matrix)
        assert isinstance(output_binary, bool)

        tmp = np.abs(spa_mat)
        mat = (tmp + tmp.transpose()).toarray()

        if output_binary:
            mat = np.where(mat > 0, 1, 0)

        return mat

    @staticmethod
    def _tsgen(anchor_ts: int, step_size: int, window_size: int):
        """
        Timestamp generator. Given an anchor timestamp, find multiple previous timestamp using user
        specified step size and window size.

        Notes
        ----------
        We assume anchor_ts and step_size are in format of millisecond. This function does not check
        if the inputs are valid.

        *The anchor_ts is included.*

        Parameters
        ----------
        anchor_ts: int. Millisecond that represents the most recent timestamp.
        step_size: int. Millisecond that represents interval length between two consecutive timestamp.
        Typically, it is 60000, which is equivalent to 1 minute.
        window_size: int. Number of timestamps/snapshots that will be used for input. Typically this
        value is greater than or equal 2.

        Returns
        -------
        list. A sorted list that contains all timestamps within a window.

        """
        assert isinstance(step_size, int) and step_size > 0
        assert isinstance(window_size, int) and window_size >=2

        ts_begin = anchor_ts - ((window_size - 1) * step_size)
        # ts_end will not be included in np.arange
        ts_end = anchor_ts + step_size

        assert ts_begin > 0

        return np.arange(ts_begin, ts_end, step_size).tolist()

    def multi_snapshots(self, snapshot_dict: dict, snapshot_ts_list: list):
        """
        Given a list of sorted timestamp, extract snapshot of significance network from
        snapshot_dict and return a tensor.

        Notes
        ----------
        We assume each snapshots in snapshot_dict are of same size. This function does not check their shapes.

        Parameters
        ----------
        snapshot_dict: dict. Dictionary that contains snapshots, with timestamps as key and significance network
        using sparse matrix representation as values.
        snapshot_ts_list: list. A list of timestamp whose significance network data will be extracted.

        Returns
        -------
        numpy.ndarray. 3D array that representing network snapshots of a time window.

        """
        if not snapshot_dict:
            raise ValueError("Input dictionary is empty.")

        if not snapshot_ts_list:
            raise ValueError("Input timestamps list is empty.")

        # note we sort list reversely, the reason is that the snapshot dictionary might
        # not contain all timestamps, if the beginning of time window is earlier than
        # first timestamp in dictionary
        ts_list = snapshot_ts_list.copy() # may not need this, just in case here
        ts_list.sort(reverse=True)

        anchor_ts = ts_list[0]
        assert anchor_ts in snapshot_dict

        axis1, axis2 = snapshot_dict[anchor_ts].shape

        P = np.zeros((len(ts_list), axis1, axis2))

        snapshots = {ts: snapshot_dict[ts] for ts in set(ts_list).intersection(snapshot_dict.keys())}
        n = len(snapshots)

        # ensure that temporal order is preserved, fill P from backwards,
        # note that snapshot_ts_list is sorted in descending
        for i in range(n):
            pos = n - i - 1
            # preprocess individual significance network
            p_proc = self.preprocess(snapshots[ts_list[i]], output_binary=False)
            # back fill
            P[pos, :, :] = p_proc

        return P


    def _optENMF(self, A, P, M, c, tau):

        n = A.shape[0]  # Number of samples
        B = np.eye(n) - c*A
        B = np.linalg.inv(B)
        B = (1.0 - c)*B
        BtB = B.T@B

        t = 1e-6

        e = np.ones((n,1))
        obj_1 = B@e@e.T@B.T
        obj_1 = obj_1*M - P
        obj_1 = np.linalg.norm(obj_1, 'fro')
        obj_2 = tau*np.linalg.norm(e, 1)
        obj = obj_1*obj_1 + obj_2

        err = 1.0
        it = 0

        max_it = 5000
        e_old = e
        obj_old = np.copy(obj)
        err_records = []

        while (err > t and it < max_it):
            #num = ((B.T@P)*M)@B@e * 4.0
            #den = ((BtB@e@e.T@B.T)*M)@B@e*4.0 + tau
            num = (B.T@(P*M))@B@e * 4.0
            den = B.T@((B@e@e.T@B.T)*M)@B@e*4.0 + tau
            e = e * np.sqrt(np.sqrt(np.divide(num, den)))

            obj_1 = B@e@e.T@B.T
            obj_1 = obj_1*M - P
            obj_1 = np.linalg.norm(obj_1, 'fro')
            obj_2 = tau*np.linalg.norm(e, 1)
            obj = obj_1*obj_1 + obj_2

            err = np.fabs(obj - obj_old)
            obj_old = np.copy(obj)

            err_records.append(err)

            it += 1

            #print progess
            if it%100 == 0:
                print("Iteration: {}\r".format(it))

        return e.reshape((n,))

    def _optENMFEvol_k(self, A, P, M, c, tau, alpha):
        """ multiple snapshot smoothing, output last snapshot ranking score,
        P is a tensor of multiple snapshots, the last element is
        the most recent time snapshot(the anomaly reporting time)
        """
        # assert P.shape[0] > 1, "Error, the P matrix contains less than two snapshots"

        n = A.shape[0]
        B = np.eye(n) - c*A
        B = np.linalg.inv(B)
        B = (1.0 - c)*B

        t = 1e-6

        # Number of snapshots
        k = P.shape[0]

        e = np.ones((n, k))

        err = 1.0
        it = 0
        max_it = 500
        e_old = np.copy(e)

        while (err > t and it < max_it):
            for i in range(k-1):
                e_k = np.copy(e[:,i]).reshape((n,1))
                e_kk = np.copy(e[:, i+1]).reshape((n,1))
                num_k = (B.T@(P[i,:,:,]*M))@B@e_k*4.0 + e_kk*alpha*2.0
                den_k = B.T@((B@e_k@e_k.T@B.T)*M)@B@e_k*4.0 + e_k*alpha*2.0 + tau

                tmp = e_k*np.sqrt(np.sqrt(np.divide(num_k, den_k)))
                e[:, i] = tmp.reshape((n,))

                num_kk = (B.T@(P[i+1,:,:]*M))@B@e_kk*4.0 + e_k*alpha*2.0
                den_kk = B.T@((B@e_kk@e_kk.T@B.T)*M)@B@e_kk*4.0 + e_kk*alpha*2.0 + tau
                tmp = e_kk*np.sqrt(np.sqrt(np.divide(num_kk, den_kk)))
                e[:, i + 1] = tmp.reshape((n,))

            err = 0

            for i in range(k):
                e_k = e[:,i].reshape((n,1))
                err = err + np.linalg.norm(e_k - e_old[:,i], 'fro')

            e_old = np.copy(e)
            it += 1
            # with 500 max iteration, doesn't look like converging, results are consistent with Matlab codes.
            # print(it)
            # print(err)

        return e[:,-1].ravel()

    def _optENMFSoft(self, A, P, M, c, tau):
        # Require softmax function
        from scipy.special import softmax

        n = A.shape[0]  # Number of samples
        B = np.eye(n) - c*A
        B = np.linalg.inv(B)
        B = (1.0 - c)*B
        BtB = B.T@B

        t = 1e-30

        e = np.ones((n,1))
        s = softmax(B@e)

        obj_1 = s@s.T
        obj_1 = obj_1*M - P
        obj_1 = np.linalg.norm(obj_1, 'fro')
        obj_2 = tau*np.linalg.norm(e, 1)
        obj = obj_1*obj_1 + obj_2

        err = 1.0
        it = 0
        max_it = 500 

        e_old = np.copy(e)
        obj_old = np.copy(obj)
        err_records = []

        while (err > t and it < max_it):
            s = softmax(B@e)
            phi = np.diag(s.ravel()) - s@s.T

            num = (B.T@phi)@(P*M)@s * 4.0
            num[num < 0.] = 0.
            den = B.T@((phi@s@s.T)*M)@s*4.0 + tau
            e = e * np.sqrt(np.sqrt(np.divide(num, den)))

            obj_1 = s@s.T
            obj_1 = obj_1*M - P
            obj_1 = np.linalg.norm(obj_1, 'fro')
            obj_2 = tau*np.linalg.norm(e, 1)
            obj = obj_1*obj_1 + obj_2

            err = np.fabs(obj - obj_old)
            err_records.append(err)
            obj_old = np.copy(obj)

            it += 1

            #print progess
            if it%100 == 0:
                print("Iteration: {}\r".format(it))

        return e.reshape((n,))

    def _optENMFSoftEvol_k(self, A, P, M, c, tau, alpha):
        # Require softmax function
        from scipy.special import softmax

        n = A.shape[0]  # Number of samples
        B = np.eye(n) - c*A
        B = np.linalg.inv(B)
        B = (1.0 - c)*B
        BtB = B.T@B

        t = 1e-6
        
        # Number of snapshots
        k = P.shape[0]  # P is in axis (X, Y, Z), each (Y,Z) is a snapshot, X is index

        e = np.ones((n,k))

        err = 1.0
        it = 0
        max_it = 500
        e_old = np.copy(e)

        while (err > t and it < max_it):
            for i in range(k-1):
                e_k = np.copy(e[:, i]).reshape(-1,1)
                e_kk = np.copy(e[:, i+1]).reshape(-1,1)

                s_k = softmax(B@e_k)
                s_kk = softmax(B@e_kk)
                s_k = s_k.reshape(-1,1)
                s_kk = s_kk.reshape(-1,1)
                phi_k = np.diag(s_k.ravel()) - s_k@s_k.T
                phi_kk = np.diag(s_kk.ravel()) - s_kk@s_kk.T
                
                num_k = (B.T@phi_k)@(P[i]*M)@s_k*4.0 + e_kk*alpha*2.0
                num_k[num_k < 0.] = 0.
                den_k = B.T@((phi_k@s_k@s_k.T)*M)@s_k*4.0 + e_k*alpha*2.0 + tau
                temp_k = e_k*np.sqrt(np.sqrt(np.divide(num_k, den_k)))
                e[:,i] = temp_k.ravel()
                
                num_kk = (B.T@phi_kk)@(P[i+1]*M)@s_k*4.0 + e_k*alpha*2.0  
                num_kk[num_kk < 0.] = 0.
                den_kk = B.T@((phi_kk@s_kk@s_kk.T)*M)@s_kk*4.0 + e_kk*alpha*2.0 + tau
                temp_kk = e_kk*np.sqrt(np.sqrt(np.divide(num_kk, den_kk)))
                e[:,i+1] = temp_kk.ravel()

            err = 0.0
            for i in range(k):
                err_term = e[:,i] - e_old[:,i]
                err +=  np.linalg.norm(err_term)

            e_old = np.copy(e)

            it += 1

            #print progess
            if it%100 == 0:
                print("Iteration: {}\r".format(it))

        return e[:, -1]

    ############ public API ####################
    def ranking(self, A, P, M, param={}):
        # Info
        print("The selected model is: {}".format(param['alg']))

        if param['alg'] == 'ENMF':
            c = param['c']
            tau = param['tau']
            e = self._optENMF(A, P, M, c, tau)
            return e
        elif param['alg'] == 'ENMFEvol':
            c = param['c']
            tau = param['tau']
            alpha = param['alpha']
            e = self._optENMFEvol_k(A, P, M, c, tau, alpha)
            return e
        elif param['alg'] == 'ENMFSoft':
            c = param['c']
            tau = param['tau']
            e = self._optENMFSoft(A,P,M,c,tau)
            return e
        elif param['alg'] == 'ENMFSoftEvol':
            c = param['c']
            tau = param['tau']
            alpha = param['alpha']
            e = self._optENMFSoftEvol_k(A, P, M, c, tau, alpha)
            return e
        else:
            print("Error, the algorithm: ({0}) you choose is not implemented.".format(param['alg']))
            sys.exit(-1)
