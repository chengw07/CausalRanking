
clear all;

data=zeros(8,2);
data(1,:)=[1,6];
data(2,:)=[2,7];
data(3,:)=[3,7];
data(4,:)=[2,5];
data(5,:)=[4,2];
data(6,:)=[5,3];
data(7,:)=[6,1];
data(8,:)=[6,2];


N = size(data,1);

P=zeros(N,N);
P(1,2)=1;
P(1,4)=1;
P(5,6)=1;
P(5,7)=1;
P(5,8)=1;
P=P+P';

function [ A, A1 ] = getAff( data )
    
    N=size(data,1);
    % Center and normalize the data attributes. Each row is an instace and
    % each column is an attribute.
    for i = 1:size(data,2)
        data(:,i) = data(:,i) - mean(data(:,i));
    end
    my_var = var(data);
    % The size of the data set

    % Compute the similarity matrix A using RBF kernel.
    % Set diagonal entries to 0 for numerical consideration.
    A = zeros(N,N);
    for i = 1:N
        for j=(i+1):N
            A(i,j) = exp(-1*sum((data(i,:)-data(j,:)).^2./(2*my_var)));
            A(j,i) = A(i,j);
        end
    end

    % Compute the graph Laplacian.
    D = diag(sum(A)); vol = sum(diag(D)); D_norm = D^(-1/2);
    A1= D_norm*A*D_norm;

end


[A, A1] = getAff( data );

% Normalize P
%D1 = diag(sum(P)); vol = sum(diag(P)); D_norm1 = D1^(-1/2);
%P1= D_norm1*P*D_norm1;

M=(A>=A(4,5));
A=A.*M;
A1=A1.*M;

%% Parameter Setting
c=0.5;
tau=1;
lambda = 1;

%% for ENMFSoft
alpha=0.3

%% Time consuming
tic;
e=optENMFSoft(A1,P,M,c,tau);

tstart = tic;
telapsed = toc(tstart);


