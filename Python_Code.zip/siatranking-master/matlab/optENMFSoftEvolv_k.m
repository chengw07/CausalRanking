%% multiple snapshot smoothing, output last snapshot ranking score, P is a cell(in python, this is a tensor) of multiple snapshots, the last element is
%% the most recent time snapshot(the anomaly reporting time)
function [ res ] = optENMFSoftEvolv_k( A, P, M, c, tau, alpha )

    n=size(A,1);
    B=(1-c)*inv(eye(n)-c*A);
    B_trans_B = B'*B;
    
    t= 10^(-6);
    % nubmer of snapshots
    k = length(P);
    
    e = ones(n, k);
        
    err = 1;
    iter = 0;
    
    maxIter = 5;
    e_old = e;
    
    while( err > t && iter < maxIter )
        
        
        for i=1:k-1
            e_k = e(:, i);
            e_kk = e(:, i+1);
            
            
            s_k=softmax(B*e_k);
            s_kk=softmax(B*e_kk);
            phi_k=diag(s_k)-s_k*s_k';
            phi_kk=diag(s_kk)-s_kk*s_kk';
            
            
            numerator_k = 4*(B'*phi_k)*(P{i}.*M)*s_k+2*alpha*e_kk;
            numerator_k(numerator_k<0)=0;
            denominator_k = 4*B'*((phi_k*s_k*s_k').*M)*s_k+tau*ones(n,1)+2*alpha*e_k;
            e(:, i)=e_k.*sqrt(sqrt(numerator_k./denominator_k));

            numerator_kk = 4*(B'*phi_kk)*(P{i+1}.*M)*s_k+2*alpha*e_k;
            numerator_kk(numerator_kk<0)=0;
            denominator_kk = 4*B'*((phi_kk*s_kk*s_kk').*M)*s_kk+tau*ones(n,1)+2*alpha*e_kk;
            e(:, i+1)=e_kk.*sqrt(sqrt(numerator_kk./denominator_kk));
            
        end
        err = 0;
        
        for i=1:k
            e_k = e(:, i);
            err= err + norm(e_k-e_old(:, i),'fro');
        end
        e_old = e;
        
        iter = iter +1;
        
    end
    res = e(:,k);
    disp(iter);
    
end

