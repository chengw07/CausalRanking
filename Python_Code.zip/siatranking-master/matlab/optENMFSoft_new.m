function [ e ] = optENMFSoft_new( A, P, M, c, tau )

    n=size(A,1);
    B=(1-c)*inv(eye(n)-c*A);
    B_trans_B = B'*B;
    
    t= 10^(-30);
    
    
    e=ones(n,1);%rand(n,1);
    s=softmax(B*e);
    obj=norm((s*s').*M-P,'fro')^2+tau*norm(e,1);
    obj_old=obj;
    err = 1;
    iter = 0;
    
    maxIter = 5;
    errorV=[];
    
    while( err > t && iter < maxIter )
        s=softmax(B*e);
        phi=diag(s)-s*s';
        
        
        numerator = 4*(B'*phi)*(P.*M)*s;
        numerator(numerator<0)=0;
        denominator = 4*B'*((phi*s*s').*M)*s+tau*ones(n,1);
        e=e.*sqrt(sqrt(numerator./denominator));
        %err=norm(e-e_old,'fro');
        obj=norm((s*s').*M-P,'fro')^2+tau*norm(e,1);
        err=abs(obj-obj_old);
        obj_old=obj;
        iter = iter +1;
        errorV=[errorV err];
    end
    disp(iter);
    %figure;
    %plot(errorV);
end

