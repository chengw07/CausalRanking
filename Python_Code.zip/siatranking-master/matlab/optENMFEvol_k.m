%% multiple snapshot smoothing, output last snapshot ranking score, P is a cell(in python, this is a tensor) of multiple snapshots, the last element is
%% the most recent time snapshot(the anomaly reporting time)

function [ res ] = optENMFEvol_k( A, P, M, c, tau, alpha )

    n=size(A,1);
    B=(1-c)*inv(eye(n)-c*A);
 
    
    t= 10^(-6);
    % nubmer of snapshots
    k = length(P);
    
    e = ones(n, k);
        
    err = 1;
    iter = 0;
    
    maxIter = 500;
    e_old = e;
 
    
    while( err > t && iter < maxIter )
        
        for i=1:k-1
            e_k = e(:, i);
            e_kk = e(:, i+1);
            numerator_k = 4*(B'*(P{i}.*M))*B*e_k+2*alpha*e_kk;
            denominator_k = 4*B'*((B*e_k*e_k'*B').*M)*B*e_k+tau*ones(n,1) + 2*alpha*e_k;
            e(:, i)=e_k.*sqrt(sqrt(numerator_k./denominator_k));
            
            numerator_kk = 4*(B'*(P{i+1}.*M))*B*e_kk+2*alpha*e_k;
            denominator_kk = 4*B'*((B*e_kk*e_kk'*B').*M)*B*e_kk+tau*ones(n,1)+2*alpha*e_kk;
            e(:, i+1)=e_kk.*sqrt(sqrt(numerator_kk./denominator_kk));
        end
        err = 0;
        
        for i=1:k
            e_k = e(:, i);
            err= err + norm(e_k-e_old(:, i),'fro');
        end
        e_old = e;
        
        iter = iter +1;
    end
    
    res = e(:,k);
    
    disp(iter);
end

