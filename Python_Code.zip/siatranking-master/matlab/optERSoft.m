function [ e, r] = optERSoft( A, P, M, c, tau, lambda )

    n=size(A,1);
    
    t= 10^(-6);
    
    r=zeros(n,1);
    r(sum(P)>0)=1;
    r=r+10^(-6);
    
    e=r;
    %obj=ERObj( A, M, P, r, e, lambda, tau, c );
    r_old=r;
    err = 1;
    iter = 0;
    
    maxIter = 500;
    
    while( err > t && iter < maxIter )
        s=softmax(r);
      %  diags=diag(s);
        sst=s*s';
        sts=s'*s;
       
        
        numerator = c/2*(A+A')*r+2*lambda*((s*ones(1,n)).*P+sts*sst).*M*s+(1-c)*e;
        denominator = r+2*lambda*((s.*s)*s'+s*(s'*P)).*M*s;
        numerator(numerator<0)=0;
        r=r.*gsqrt(gsqrt(gdivide(numerator,denominator)));
        r(isnan(r))=0;
        
        numerator = 2*(1-c)*r;
        denominator = tau*ones(n,1)+2*(1-c)*e;
        e=e.*gsqrt(gdivide(numerator,denominator));
        err=norm(r-r_old,'fro');
        %obj=ERObj( A, M, P, r, e, lambda, tau, c );
        %err=abs(obj-obj_old);
        r_old=r;
        iter = iter +1;
    end
    disp(iter);
    
end

