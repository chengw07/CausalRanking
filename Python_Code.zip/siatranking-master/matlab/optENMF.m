function [ e ] = optENMF( A, P, M, c, tau )

    n=size(A,1);
    B=(1-c)*inv(eye(n)-c*A);
    B_trans_B = B'*B;
    
    t= 10^(-6);
    
    e=ones(n,1);%rand(n,1);
    obj=norm((B*e*e'*B').*M-P,'fro')^2+tau*norm(e,1);
%    obj_old=obj;
    err = 1;
    iter = 0;
    
    maxIter = 500;
    e_old = e;
    
    while( err > t && iter < maxIter )
        numerator = 4*((B'*P).*M)*B*e;
        denominator = 4*((B_trans_B*e*e'*B').*M)*B*e+tau*ones(n,1);
        e=e.*sqrt(sqrt(numerator./denominator));
        err=norm(e-e_old,'fro');
        %obj=norm((B*e*e'*B').*M-P,'fro')^2+tau*norm(e,1);
        %err=abs(obj-obj_old);
        %obj_old=obj;
        e_old=e;
        iter = iter +1;
    end
    
    disp(iter);
end

