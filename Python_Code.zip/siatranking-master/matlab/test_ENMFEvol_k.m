
clear all;

% Load the data
data=zeros(8,2);
data(1,:)=[1,6];
data(2,:)=[2,7];
data(3,:)=[3,7];
data(4,:)=[2,5];
data(5,:)=[4,2];
data(6,:)=[5,3];
data(7,:)=[6,1];
data(8,:)=[6,2];

N = size(data,1);

P=zeros(N,N);
P(1,2)=1;
P(1,4)=1;
P(5,6)=1;
P(5,7)=1;
P(5,8)=1;
P=P+P';

[A, A1] = getAff( data );

% Normalize P
%D1 = diag(sum(P)); vol = sum(diag(P)); D_norm1 = D1^(-1/2);
%P1= D_norm1*P*D_norm1;

M=(A>=A(4,5));
A=A.*M;
A1=A1.*M;

PC = {P, P};

%% Parameter Setting
c=0.5;
tau=0.5;
alpha=0.3;


%% Time consuming
tic;
%e=optENMFEvol_k(A1,PC,M,c,tau,alpha);
e=optENMFSoftEvolv_k(A1,PC,M,c,tau,alpha);

csvwrite('ENMFSoft.csv', e);

tstart = tic;
telapsed = toc(tstart);


