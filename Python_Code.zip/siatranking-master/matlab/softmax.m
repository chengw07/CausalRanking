function [r] = softmax(v)
    r = exp(v)/sum(exp(v));
end