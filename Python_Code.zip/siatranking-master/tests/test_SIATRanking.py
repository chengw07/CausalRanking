# -*- coding: utf-8 -*-


import sys
import os
sys.path.insert(0,os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import numpy as np
from siatranking.siat_ranking import SIATRanking


def test_optENMF():
    # Generate data
    
    data = np.array([[1,6],
                     [2,7],
                     [3,7],
                     [2,5],
                     [4,2],
                     [5,3],
                     [6,1],
                     [6,2]])
    
    N = data.shape[0]
    P = np.zeros((N,N))
    P[0,1] = 1
    P[0,3] = 1
    P[4,5] = 1
    P[4,6] = 1
    P[4,7] = 1
    P += P.T

    sr = SIATRanking()
    
    A, A1 = sr.calc_affinity_matrix(data)

    M = A>= A[3,4]
    M = M.astype(np.int)
    
    A = A*M
    A1 = A1*M

    param={}
    param['c'] = 0.5
    param['tau'] = 1.0
    param['lambda'] = 1.0

    param['alg'] = 'ENMF'
    e = sr.ranking(A1, P, M, param)

    grand_truth = [1.6042e+00,
                   4.6774e-01,
                   4.1973e-17,
                   2.8993e-06,
                   2.4911e+00,
                   2.0844e-01,
                   2.7560e-01,
                   2.6047e-01]
    grand_truth = np.array(grand_truth)
    
    print('The score results are: {}'.format(e))
    assert np.sum(np.fabs(grand_truth - e)) < 1e-5

def test_optENMFSoft():
    sr = SIATRanking()
    # Generate data
    data = np.array([[1,6],
                     [2,7],
                     [3,7],
                     [2,5],
                     [4,2],
                     [5,3],
                     [6,1],
                     [6,2]])
    
    N = data.shape[0]
    P = np.zeros((N,N))
    P[0,1] = 1
    P[0,3] = 1
    P[4,5] = 1
    P[4,6] = 1
    P[4,7] = 1
    P += P.T
    A, A1 = sr.calc_affinity_matrix(data)
    M = A>= A[3,4]
    M = M.astype(np.int)
    A = A*M
    A1 = A1*M
    
    sr = SIATRanking()

    param={}
    param['c'] = 0.5
    param['tau'] = 1.0

    param['alg'] = 'ENMFSoft'
    e = sr.ranking(A1, P, M, param)

    grand_truth = [0.004121,
                   0.000000,
                   0.000000,
                   0.000000,
                   0.026590,
                   0.000000,
                   0.000000,
                   0.000000]
    grand_truth = np.array(grand_truth)
    
    print('The score results are: {}'.format(e))
    np.savetxt("ENMPSoft_result.csv", e, delimiter=",")
    assert np.sum(np.fabs(grand_truth - e)) < 1e-5

def test_optENMFEvol_k():
    sr = SIATRanking()
    # Generate data
    data = np.array([[1,6],
                     [2,7],
                     [3,7],
                     [2,5],
                     [4,2],
                     [5,3],
                     [6,1],
                     [6,2]])
    
    N = data.shape[0]
    P = np.zeros((N,N))
    P[0,1] = 1
    P[0,3] = 1
    P[4,5] = 1
    P[4,6] = 1
    P[4,7] = 1
    P += P.T
    A, A1 = sr.calc_affinity_matrix(data)
    M = A>= A[3,4]
    M = M.astype(np.int)
    A = A*M
    A1 = A1*M

    PC = np.zeros((2, P.shape[0], P.shape[1]))
    PC[0] = P
    PC[1] = P
    
    sr = SIATRanking()

    param={}
    param['c'] = 0.5
    param['tau'] = 0.5
    param['alpha'] = 0.3

    param['alg'] = 'ENMFEvol'
    e = sr.ranking(A1, PC, M, param)
    
    print('The score results are: {}'.format(e.reshape(-1,1)))
    np.savetxt("ENMPEvol_k_result.csv", e, delimiter=",")
    assert True == True

def test_optENMFSoftEvol_k():
    sr = SIATRanking()
    # Generate data
    data = np.array([[1,6],
                     [2,7],
                     [3,7],
                     [2,5],
                     [4,2],
                     [5,3],
                     [6,1],
                     [6,2]])
    
    N = data.shape[0]
    P = np.zeros((N,N))
    P[0,1] = 1
    P[0,3] = 1
    P[4,5] = 1
    P[4,6] = 1
    P[4,7] = 1
    P += P.T
    A, A1 = sr.calc_affinity_matrix(data)
    M = A>= A[3,4]
    M = M.astype(np.int)
    A = A*M
    A1 = A1*M
    
    PC = np.zeros((2, P.shape[0], P.shape[1]))
    PC[0] = P
    PC[1] = P
    
    sr = SIATRanking()

    param={}
    param['c'] = 0.5
    param['tau'] = 0.5
    param['alpha'] = 0.3

    param['alg'] = 'ENMFSoftEvol'
    e = sr.ranking(A1, PC, M, param)
    
    print('The score results are: {}'.format(e.reshape(-1,1)))
    np.savetxt("ENMPSoftSoftEvol_k_result.csv", e, delimiter=",")
    assert True == True


if __name__ == '__main__':
    #test_optENMF()
    #test_optENMFSoft()
    #test_optENMFEvol_k()
    test_optENMFSoftEvol_k()

