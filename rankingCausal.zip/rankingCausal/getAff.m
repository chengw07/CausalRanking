function [ A, A1 ] = getAff( data )
    
    N=size(data,1);
    % Center and normalize the data attributes. Each row is an instace and
    % each column is an attribute.
    for i = 1:size(data,2)
        data(:,i) = data(:,i) - mean(data(:,i));
    end
    my_var = var(data);
    % The size of the data set

    % Compute the similarity matrix A using RBF kernel.
    % Set diagonal entries to 0 for numerical consideration.
    A = zeros(N,N);
    for i = 1:N
        for j=(i+1):N
            A(i,j) = exp(-1*sum((data(i,:)-data(j,:)).^2./(2*my_var)));
            A(j,i) = A(i,j);
        end
    end

    % Compute the graph Laplacian.
    D = diag(sum(A)); vol = sum(diag(D)); D_norm = D^(-1/2);
    A1= D_norm*A*D_norm;

end

