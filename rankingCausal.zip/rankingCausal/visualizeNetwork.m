function visualizeNetwork( data, A, P, e)
    figure;
    hold on;
    n=size(A,1);
    subplot(1,2,1);
    
    scatter(data(:,1),data(:,2));
    title('Invariant Network and Broken Edges','FontSize',18);
    
    dx = 0.1; dy = 0.1; % displacement so the text does not overlay the data points
    b = [1:n]';
    b = num2str(b); 
    b = cellstr(b);
    text(data(:,1)+dx, data(:,2)+dy, b);
    
    maxV= max(max(A,1),2);
    maxV=maxV(1,1);
    
    hold on;

    for i=1:n
        for j=i+1:n
            x=data(i,:);
            y=data(j,:);
            p1=[x(1);y(1)];
            p2=[x(2);y(2)];
            %midx=(data(i,1)+data(j,1))/2;
            %midy=(data(i,2)+data(j,2))/2;
            linewidth=5*A(i,j)/maxV;
            
            if( A(i,j)>0&&P(i,j)==0 )
                
                plot(p1,p2,'xb-','LineWidth',linewidth);
      %          text(midx,midy,num2str(A(i,j)));
            else if( A(i,j)>0 )
             
                plot(p1,p2,'xr-','LineWidth',linewidth);
      %          text(midx,midy,num2str(A(i,j)));
                end
            end
           
        end
    end
    
    subplot(1,2,2);
    
    imagesc(e);
    title('Abnormal Values','FontSize',18);
    hold on;
    colorbar;
    
end

