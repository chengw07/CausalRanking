The demo code only show how to run the main code in 
�Ranking Causal Anomalies via Temporal and Dynamical
Analysis on Vanishing Correlations�. 

To get start, simply run run.m. The current invariant network and broken network are all generated manually for
demonstration. The visualizeNetwork will show the results and initial input.

For real problem, you need first run AutoRegressive eXogenous (ARX) mode to generate invariant network from training time series, and check the residuals on testing period to get broken network for different time snapshots. Then feed the algorithm with the two networks for ranking.