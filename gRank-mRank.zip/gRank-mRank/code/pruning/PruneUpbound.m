function [Inv, Percentage, PrunedPercentage] = PruneUpbound(Series, SampleIndexs, RemainedListAfterPrevious, Count0, Threshold)
% This function is to do pruning with selected partial samples (points)

% Series: the time series
% SampleIndexs: the indexs of selected samples from each signal, minimu is 4
% RemainedListAfterPrevious: the pair list with size Count2
% pruning with upbound: one time effor


[NumSeries,NumSamples]=size(Series);
%% get the various for all series
denomis=(NumSamples-3)*var(Series(:,4:end),1,2);
InvIndex =zeros(Count0,2);
CountInv=1;
CountNotPruned=0;
for c=1:Count0
    Indexs=RemainedListAfterPrevious(c,:);
    SampleIndex_Y=SampleIndexs{Indexs(1),:};
    Y1 = Series(Indexs(1),SampleIndex_Y)';
    X1 = [Series(Indexs(1),SampleIndex_Y-1)',Series(Indexs(1),SampleIndex_Y-2)', Series(Indexs(1),SampleIndex_Y-3)', Series(Indexs(2),SampleIndex_Y)', Series(Indexs(2),SampleIndex_Y-1)', Series(Indexs(2),SampleIndex_Y-2)', ones(length(SampleIndex_Y),1)];
    [error1, theta1]=linearmultireg(Y1,X1);
    upbound1st=1-sqrt(error1/denomis(Indexs(1)));      
    if upbound1st<Threshold(1)
        continue;
    end
    SampleIndex_Y=SampleIndexs{Indexs(2),:};    
    Y2 = Series(Indexs(2),SampleIndex_Y)';
    X2 = [Series(Indexs(2),SampleIndex_Y-1)',Series(Indexs(2),SampleIndex_Y-2)', Series(Indexs(2),SampleIndex_Y-3)', Series(Indexs(1),SampleIndex_Y)', Series(Indexs(1),SampleIndex_Y-1)', Series(Indexs(1),SampleIndex_Y-2)', ones(length(SampleIndex_Y),1)];
    [error2, theta2]=linearmultireg(Y2,X2);
    upbound2nd=1-sqrt(error2/denomis(Indexs(2)));      
    if upbound2nd<Threshold(1)
        continue;
    end
    if max([upbound1st,upbound2nd])<Threshold(2)
       continue;
    end
    
    CountNotPruned=CountNotPruned+1;
    Series_i = Series(Indexs(1),:);
    Series_j = Series(Indexs(2),:);
    NumSamples=length(Series_i);
    Y = Series_i(4:end)';
    X = [Series_i(3:NumSamples-1)',Series_i(2:NumSamples-2)', Series_i(1:NumSamples-3)', Series_j(4:end)', Series_j(3:NumSamples-1)', Series_j(2:NumSamples-2)', ones(NumSamples-3,1)];        
    [error1, theta2]=linearmultireg(Y, X);    
    R_ij = 1-sqrt(error1/denomis(Indexs(1))); %R_ij=1;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Y = Series_j(4:end)';
    X = [Series_j(3:NumSamples-1)',Series_j(2:NumSamples-2)', Series_j(1:NumSamples-3)', Series_i(4:end)', Series_i(3:NumSamples-1)', Series_i(2:NumSamples-2)', ones(NumSamples-3,1)];
    [error2, theta2]=linearmultireg(Y, X);
    R_ji = 1-sqrt(error2/denomis(Indexs(2))); %R_ji=1;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if (R_ij>=Threshold(1) && R_ji>=Threshold(1) && max(R_ji,R_ij)>=Threshold(2))
        if R_ji>=R_ij
            InvIndex(CountInv,:) = [Indexs(2),Indexs(1)];
        else
            InvIndex(CountInv,:) = [Indexs(1),Indexs(2)];
        end
        CountInv=CountInv+1;
    end        
end
Inv=InvIndex(1:(CountInv-1),:);
Percentage = size(Inv,1)/(NumSeries*(NumSeries-1)/2);
PrunedPercentage=(Count0-CountNotPruned)/Count0;

end






