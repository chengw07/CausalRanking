function [Inv, Percentage]=Scratch(Series, RemainedListAfterPrevious, Count0,Threshold)

% This function is to brute-force search invariant




%% n=3, m=3, k=0;
[NumSeries,NumSamples]=size(Series);

denomis=(NumSamples-3)*var(Series(:,4:end),1,2);

InvIndex =zeros((NumSeries*NumSeries-NumSeries)/2,2);
CountInv=1;

for c=1:Count0
    
Indexs=RemainedListAfterPrevious(c,:);
i=Indexs(1);j=Indexs(2);
Series_i = Series(Indexs(1),:);
Series_j = Series(Indexs(2),:);
        Y = Series_i(4:end)';
        X = [Series_i(3:NumSamples-1)',Series_i(2:NumSamples-2)', Series_i(1:NumSamples-3)', Series_j(4:end)', Series_j(3:NumSamples-1)', Series_j(2:NumSamples-2)', ones(NumSamples-3,1)];
        
        [error1, theta1]=linearmultireg(Y, X);
        R_ij = 1-sqrt(error1/denomis(i));    %R_ij=1; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Y = Series_j(4:end)';
        X = [Series_j(3:NumSamples-1)',Series_j(2:NumSamples-2)', Series_j(1:NumSamples-3)', Series_i(4:end)', Series_i(3:NumSamples-1)', Series_i(2:NumSamples-2)', ones(NumSamples-3,1)];

        [error2, theta2]=linearmultireg(Y, X);
        R_ji = 1-sqrt(error2/denomis(j));    %R_ji=1;  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if (R_ij>=Threshold(1) && R_ji>=Threshold(1) && max(R_ji,R_ij)>=Threshold(2))
            if R_ji>=R_ij
                InvIndex(CountInv,:) = [j,i];
            else
                InvIndex(CountInv,:) = [i,j];
            end
            CountInv=CountInv+1;
        end
    
end

Inv=InvIndex(1:CountInv-1,:);

Percentage = size(Inv,1)/(NumSeries*(NumSeries-1)/2);








end