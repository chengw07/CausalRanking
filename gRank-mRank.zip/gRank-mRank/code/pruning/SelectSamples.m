

function SampleIndexs = SelectSamples(Series,P,ind)

% This function is to select samples from each time series

% SampleIndexs(N x K): the indexs of selected samples for each signal 
% ind can be 'random', 'changepoint' or 'highvalue'
% P: the percentage of selected samples

NumSelSamples=floor(size(Series,2)*P);
SampleIndexs=cell(size(Series,1),NumSelSamples);
if strcmp(ind, 'random')
    for i=1:size(Series,1)
        SampleIndexs{i,1}=randperm(size(Series,2)-3)+3;
    end
elseif strcmp(ind,'changepoint')
    for i=1:size(Series,1)
        Y=Series(i,4:end);
        Ydiff = Y(2:end)-Y(1:length(Y)-1);    
        Ydiff = abs(Ydiff);    
        [SortYdiff, Index]=sort(Ydiff,'descend');    
        Index_Seled = Index(1:(NumSelSamples/2));
        temp = [Index_Seled, (Index_Seled+1)];
        Index_Seled = unique(temp);
        SampleIndexs{i,1}=Index_Seled+3;
    end
else % select points with high value
      
end
%if min(min(SampleIndexs)<4)
%    error('minimum index of selected sample is less than 4');
% end

end
