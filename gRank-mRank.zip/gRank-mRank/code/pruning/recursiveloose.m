function [Inv, Percentage, T]=recursiveloose(Series, RemainedListAfterPrevious, Count0, Threshold)
% recursively update the loose upbound while memorize middle-step results

% input:
% Series: time series matrix, each row is a time series
% RemainedListAfterPrevious: all pairs of time series
% Count0: the number of all pairs
% Threshold: like [0.5,0.7]

%% Overhead:
%  1. (Scan all pairs or matrix) <- keep saving remained pair list (copy index of remained pairs)
%  2. For each pair, reform the Y and X(matrix) with whole samples <- at each step, only reform the Y and X with the relevant partial samples.
%  3. Keep saving/updating sum of error
%% To do
%  1. revise multireg, make its computation linear with number of samples
%  2. complete recursive-pruning pair by pair
%  3. revise this function, write a loop outside
[NumSeries,NumWholeSamples]=size(Series);
%% get the variance for all series
denomis=(NumWholeSamples-3)*var(Series(:,4:end),1,2);
% SumError is used to record the up-to-date error for directed pair
SumError=zeros(NumSeries,NumSeries,2);

Step=20;

T=zeros(Step+1,1);
for s=1:Step
tstart_s=tic;
% RemainedLists is created to store the remained pairs after this step s
% Count1 is created to track the number of remained pairs after this step s
RemainedLists=zeros(Count0,2);
Count1=0;
for c=1:Count0
    Indexs=RemainedListAfterPrevious(c,:);
    Series_i = Series(Indexs(1),(1+(s-1)*floor(NumWholeSamples/Step)):s*floor(NumWholeSamples/Step));
    Series_j = Series(Indexs(2),(1+(s-1)*floor(NumWholeSamples/Step)):s*floor(NumWholeSamples/Step));
    NumSamples=length(Series_i);
        
    Y1 = Series_i(4:end)';
    X1 = [Series_i(3:NumSamples-1)',Series_i(2:NumSamples-2)', Series_i(1:NumSamples-3)', Series_j(4:end)', Series_j(3:NumSamples-1)', Series_j(2:NumSamples-2)', ones(NumSamples-3,1)];    
    [error1, theta1]=linearmultireg(Y1,X1);   %error1=0; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    upbound2nd1=1-sqrt((error1+SumError(Indexs(1),Indexs(2),1))/denomis(Indexs(1)));
    if upbound2nd1<Threshold(1)
        continue;
    else
        SumError(Indexs(1),Indexs(2),1)=SumError(Indexs(1),Indexs(2),1)+error1;
    end
    Y2 = Series_j(4:end)';
    X2 = [Series_j(3:NumSamples-1)',Series_j(2:NumSamples-2)', Series_j(1:NumSamples-3)', Series_i(4:end)', Series_i(3:NumSamples-1)', Series_i(2:NumSamples-2)', ones(NumSamples-3,1)];

    [error2, theta2]=linearmultireg(Y2,X2); %error2=0;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    upbound2nd2=1-sqrt((error2+SumError(Indexs(1),Indexs(2),2))/denomis(Indexs(2)));
    if upbound2nd2<Threshold(1)
       continue;
    else
       SumError(Indexs(1),Indexs(2),2)=SumError(Indexs(1),Indexs(2),2)+error2;
    end
    if max([upbound2nd1,upbound2nd2])<Threshold(2)
       continue;
    end
    Count1=Count1+1;
    RemainedLists(Count1,:)=[Indexs(1),Indexs(2)];
end
% copy the remained list after step s to RemainedListAfterPrevious
% Count0 is the number remained pairs, is need to control the number of loop of next step
RemainedListAfterPrevious=RemainedLists(1:Count1,:);
Count0=size(RemainedListAfterPrevious,1);

T(s)=toc(tstart_s);
end
%% scratch-search invariant after pruning
tstart=tic;
InvIndex =zeros(Count0,2);
CountInv=1;
for c=1:Count0
    Indexs = RemainedListAfterPrevious(c,:);
    Series_i = Series(Indexs(1),:);
    Series_j = Series(Indexs(2),:);
    NumSamples=length(Series_i);
    
    Y = Series_i(4:end)';
    X = [Series_i(3:NumSamples-1)',Series_i(2:NumSamples-2)', Series_i(1:NumSamples-3)', Series_j(4:end)', Series_j(3:NumSamples-1)', Series_j(2:NumSamples-2)', ones(NumSamples-3,1)];        
    [error1, theta1]=linearmultireg(Y, X);    
    R_ij = 1-sqrt(error1/denomis(Indexs(1))); %R_ij=1;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Y = Series_j(4:end)';
    X = [Series_j(3:NumSamples-1)',Series_j(2:NumSamples-2)', Series_j(1:NumSamples-3)', Series_i(4:end)', Series_i(3:NumSamples-1)', Series_i(2:NumSamples-2)', ones(NumSamples-3,1)];
    [error2, theta2]=linearmultireg(Y, X);
    R_ji = 1-sqrt(error2/denomis(Indexs(2))); %R_ji=1;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if (R_ij>=Threshold(1) && R_ji>=Threshold(1) && max(R_ji,R_ij)>=Threshold(2))
        if R_ji>=R_ij
            InvIndex(CountInv,:) = [Indexs(2),Indexs(1)];
        else
            InvIndex(CountInv,:) = [Indexs(1),Indexs(2)];
        end
        CountInv=CountInv+1;
    end
end
Inv=InvIndex(1:(CountInv-1),:);
T(end)=toc(tstart);
Percentage = size(Inv,1)/(NumSeries*(NumSeries-1)/2);
end