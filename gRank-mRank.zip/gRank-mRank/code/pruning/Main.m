% main function

clear
clc
close all



warning off;
data_csv=dlmread('D:\siat\python\sythetic\synthetics2000.csv');
Threshold=[0.5,0.7];
Series=data_csv(1:2000,:);

%% increase the length of series
numSamples=size(data_csv,2);
times=4;
ExtendSeries=zeros(size(Series,1),times*numSamples);
for i=1:times
    randS=randperm(numSamples);
    ExtendSeries(:,((i-1)*numSamples+1):i*numSamples)=Series(:,randS);
end
Series=ExtendSeries;



%% filter out constant signal
Temp=[];
Count=0;
for i=1:size(Series,1)
    if var(Series(i,:))~=0
        Count = Count +1;
        Temp(Count,:)=Series(i,:);
    end
end

Series=Temp;
NumSeries=size(Series,1);


%% get inital index and count0
RemainedListAfterPrevious=zeros((NumSeries*NumSeries-NumSeries)/2,2);
Count0=0;
for i=1:NumSeries
    for j=(i+1):NumSeries
        Count0=Count0+1;
        RemainedListAfterPrevious(Count0,:)=[i,j];
    end
end


%% scratch searching
tstart=tic;
[Inv1, Percentage1]=Scratch(Series, RemainedListAfterPrevious, Count0, Threshold);
t1=toc(tstart);

disp('done');


%% once-effor pruning
P=0.4;
ind='changepoint';
tstart=tic;
SampleIndexs = SelectSamples(Series,P,ind);
[Inv, Percentage, PrunedPercentage] = PruneUpbound(Series, SampleIndexs, RemainedListAfterPrevious, Count0, Threshold);
t2=toc(tstart);


%% smart search
tstart=tic;
[Inv2, Percentage2, T]=recursiveloose(Series, RemainedListAfterPrevious, Count0, Threshold);
t3=toc(tstart);

%%
disp('done')






