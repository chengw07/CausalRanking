function [error, theta]=linearmultireg(y, X)



%% y: nx1 column vector; X: nxk matrix (k is the number of indep varia)

temp=X'*X;
temp = inv(temp);
temp1 = temp*X';
theta = temp1*y;

%theta = (X'* X)\X'*y;

error = sum((y - X*theta).^2);

% denominator = sum((y-mean(y)).^2);

% fitness = 1-sqrt(error/denominator);


end