function [Invs,MNK,theta,testdata]=organize(seriestrain,attnamestrain,invsfilename,testdatafilename)

% This function is used to take the inv.xml file from SIAT engine and 
% organize the results into different format


fid1=fopen(testdatafilename);
Xs=[];
count_series=1;
seriestest=[];
attnamestest={};
while 1
    tline=fgetl(fid1);
    if ~ischar(tline),break,end
    disp(tline);
    index_times=strfind(tline,'<Times>');
    if ~isempty(index_times)
        index_times2=strfind(tline,'</Times>');
        Timestamps = tline((index_times+7):(index_times2-1));
        Times=regexp(Timestamps,',','split');
        format long
        TimestampsVec=str2double(Times);
        Xs=TimestampsVec;
    end
    
    index_att=strfind(tline,'<Attribute name="');
    if ~isempty(index_att)
        index_start=strfind(tline,'="');
        index_end=strfind(tline,'">');
        att_name=tline((index_start+2):(index_end-1));
        attnamestest{count_series,1}=att_name;
    end
    
    index_values=strfind(tline,'<Value>');
    if ~isempty(index_values)
        index_values2=strfind(tline,'</Value>');
        Values=tline((index_values+7):(index_values2-1));
        Values=regexp(Values,',','split');
        format long
        ValuesVec=str2double(Values);
        seriestest(count_series,:)=ValuesVec;
        count_series=count_series+1;
    end
    
end

numPointtest=size(seriestest,2)-1;
seriestest=seriestest(:,1:numPointtest);


fid1=fopen(invsfilename);

count_inv=1;
inv={};
while 1
    tline=fgetl(fid1);
    if ~ischar(tline),break,end
    index_uname_start=strfind(tline,'<uName>');
    if ~isempty(index_uname_start)
        index_uname_end=strfind(tline,'</uName>');
        uname = tline((index_uname_start+7):(index_uname_end-1));
        %Times=regexp(Timestamps,',','split');
        inv{count_inv}.uName=uname;
    end
    
    index_yname_start=strfind(tline,'<yName>');
    if ~isempty(index_yname_start)
        index_yname_end=strfind(tline,'</yName>');
        yname = tline((index_yname_start+7):(index_yname_end-1));
        %Times=regexp(Timestamps,',','split');
        inv{count_inv}.yName=yname;
    end
  
    index_fitness_start=strfind(tline,'<fitness>');
    if ~isempty(index_fitness_start)
        index_fit_end=strfind(tline,'</fitness>');
        fitness = tline((index_fitness_start+9):(index_fit_end-1));
        format long
        fitness = str2double(fitness);
        %Times=regexp(Timestamps,',','split');
        inv{count_inv}.fitness=fitness;
    end
    
    index_theta_start=strfind(tline,'<theta>');
    if ~isempty(index_theta_start)
        index_theta_end=strfind(tline,'</theta>');
        theta = tline((index_theta_start+7):(index_theta_end-1));
        theta=regexp(theta,',','split');
        format long
        theta=str2double(theta);
        inv{count_inv}.theta=theta;
    end
  
    
    index_n_start=strfind(tline,'<n>');
    if ~isempty(index_n_start)
        index_n_end=strfind(tline,'</n>');
        n = tline((index_n_start+3):(index_n_end-1));
        n=str2double(n);
        inv{count_inv}.n=n;
    end
    
    
    index_m_start=strfind(tline,'<m>');
    if ~isempty(index_m_start)
        index_m_end=strfind(tline,'</m>');
        m = tline((index_m_start+3):(index_m_end-1));
        m=str2double(m);
        inv{count_inv}.m=m;
    end
    
    
    index_k_start=strfind(tline,'<k>');
    if ~isempty(index_k_start)
        index_k_end=strfind(tline,'</k>');
        k = tline((index_k_start+3):(index_k_end-1));
        k=str2double(k);
        inv{count_inv}.k=k;
    end
    
    
    index_threshold_start=strfind(tline,'<threshold>');
    if ~isempty(index_threshold_start)
        index_threshold_end=strfind(tline,'</threshold>');
        threshold = tline((index_threshold_start+11):(index_threshold_end-1));
        format long
        threshold=str2double(threshold);
        inv{count_inv}.threshold=threshold;
    end
    
    
    index_slope_start=strfind(tline,'<slope>');
    if ~isempty(index_slope_start)
        index_slope_end=strfind(tline,'</slope>');
        slope = tline((index_slope_start+7):(index_slope_end-1));
        slope=str2double(slope);
        inv{count_inv}.slope=slope;
    end
    
    
    index_intercept_start=strfind(tline,'<intercept>');
    if ~isempty(index_intercept_start)
        index_intercept_end=strfind(tline,'</intercept>');
        intercept = tline((index_intercept_start+11):(index_intercept_end-1));
        intercept=str2double(intercept);
        inv{count_inv}.intercept=intercept;
        count_inv = count_inv+1;
    end
    
end



Invs=zeros(count_inv-1,2);
MNK=zeros(count_inv-1,3);
theta=cell(count_inv-1,1);

for i=1:count_inv-1
    Inv_i=inv{i};
    y=Inv_i.yName;
    x=Inv_i.uName;
    checker=0;
    for j=1:size(seriestrain,1)
        attname_j=attnamestrain{j};
        if strcmp(y,attname_j)
            Invs(i,1)=j;
            checker=checker+1;
            break;
        end
    end
    for j=1:size(seriestrain,1)
        attname_j=attnamestrain{j};
        if strcmp(x,attname_j)
            Invs(i,2)=j;
            checker=checker+1;
            break;
        end
    end
    if checker~=2
        error('metrics of an invariant are not fully identified in all series');
    end
    
    MNK_i=[Inv_i.m,Inv_i.n,Inv_i.k];
    theta_i=Inv_i.theta;
    MNK(i,:)=MNK_i;
    theta{i}=theta_i;
end



testdata=zeros(size(seriestrain,1),size(seriestest,2));
for i=1:size(seriestrain,1)
    attname_i=attnamestrain{i};
    checker=0;
    for j=1:size(seriestest,1)
        if strcmp(attname_i,attnamestest{j})
            testdata(i,:)=seriestest(j,:);
            checker=1;
            break;
        end
    end
    if checker==0
        error('metric is training set is not found in testing set');
    end
end







end
