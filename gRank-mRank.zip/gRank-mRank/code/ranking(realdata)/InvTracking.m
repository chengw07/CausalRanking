function [StatuesInv,Residuals]=InvTracking(Inv1,Thetas,MNK,SeriesExtend)

% This function is used to get the state of inv networks at certain
% timestamp

%% The invariant becomes to be borken may be later than the signal changes to be abnormal.
% this delay depends on the learned arx model

% Inv1: [i,j], i: index of y, j: index of x
% Thetas: the parameters of arx model:[y(t-1),y(t-2),y(t-3),x(t),x(t-1),x(t-2),1]
% SeriesExtend(with the same number of series as the original series): the last sample of each series is abnormal
% Residuals: all residulas are returned
% StatuesInv: 0 nonbroken, 1 broken

numInvs=size(Inv1,1);
%k=0;
Residuals=zeros(numInvs,size(SeriesExtend,2)-5);

for i=1:numInvs
    yIndex=Inv1(i,1);
    xIndex=Inv1(i,2);
    ys=SeriesExtend(yIndex,:);
    xs=SeriesExtend(xIndex,:);
    
    M=MNK(i,1);N=MNK(i,2);K=MNK(i,3);
    for j=6:size(SeriesExtend,2)
        y_j=ys(j);
        if N>0
            yhat_j=dot(Thetas{i,1},[-ys((j-N):(j-1)),xs((j-K-M):(j-K)),1]);
        else
            yhat_j=dot(Thetas{i,1},[xs((j-K-M):(j-K)),1]);
        end
        Residuals(i,j-5)=y_j-yhat_j;
    end
end

StatuesInv=zeros(numInvs,1);
numAllResi=size(Residuals,2);
for i=1:numInvs
    residualstrain=Residuals(i,1:(numAllResi-5));
    autoThreshold=1.1*prctile(abs(residualstrain),99.5);
    if abs(Residuals(i,end))>autoThreshold
        StatuesInv(i,1)=1;
    end
end





















end