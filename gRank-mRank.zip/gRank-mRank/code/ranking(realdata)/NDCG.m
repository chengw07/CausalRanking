function [nDCG,DCG]=NDCG(rankedBenchmark,abnorDegreeBench,RankedMetrics,p)
% compute nDCG measurement 
% rankedBenchmark: perfect rank (with metric IDs)
% abnorDegreeBench: relevant degree (same order as rankedBenchmark)
% RankedMetrics: ranked metrics (with IDs) with ranking algorithm
% p: the position as nDCG@p

DCG=0;
for i=1:p
    ID_i=RankedMetrics(i);
    index_ID_i_withrankedBenchmark=find(rankedBenchmark==ID_i);
    if isempty(index_ID_i_withrankedBenchmark)
        continue;
    else
        relevance_ID_i=abnorDegreeBench(index_ID_i_withrankedBenchmark);
        DCG=DCG+(2^relevance_ID_i-1)/log2(1+i);
    end
end

% ideal DCG
iDCG=0;
if p>length(rankedBenchmark)
    p=length(rankedBenchmark);
end
for i=1:p
    relevance_i=abnorDegreeBench(i);
    iDCG=iDCG+(2^relevance_i-1)/log2(1+i);
end
        

nDCG=DCG/iDCG;

end