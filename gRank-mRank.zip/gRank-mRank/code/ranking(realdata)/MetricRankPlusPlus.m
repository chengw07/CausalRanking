function [RankedMetrics,AbnScores,scoreRecords,rankRecords,m1Scores,m2Scores,finalrScores]=MetricRankPlusPlus(StatuesInv,Invs,Residuals)

% This funtion is to rank metric with Algorithm II


% interatively computing abnormaly score of each metric
numInv=size(Invs,1);
numResiduls=size(Residuals,2);

% get all nodes
% nodeID is the index of time series
allNodeIDs=unique([Invs(:,1),Invs(:,2)]);
numNodes=length(allNodeIDs);
% m1Scores is the m1 score
% -1 indicates no associated broken links
m1Scores=-ones(numNodes,1);

% initialize the m1Scores
for i=1:numNodes
    nodeID=allNodeIDs(i);
    indexs1=find(Invs(:,1)==nodeID);
    indexs2=find(Invs(:,2)==nodeID);
    numLinks=length(indexs1)+length(indexs2);
    numBrokenLinks=sum(StatuesInv(indexs1,:))+sum(StatuesInv(indexs2,:));
    if numBrokenLinks==0
        continue;
    end
    m1Scores(i)=numBrokenLinks/numLinks; 
end

[Sortedrm1Scores,ind1]=sort(m1Scores,'descend');
% a list of indexs of metrics, sorted by rScore (from high to low)
originalRank=allNodeIDs(ind1);

% iteratively update score
MaxRound=50;
% record all scores during each iteration
scoreRecords=zeros(length(m1Scores),MaxRound+1);scoreRecords(:,1)=m1Scores;
% record all rankings during each iteration
rankRecords=zeros(length(m1Scores),MaxRound+1);rankRecords(:,1)=originalRank;

for i=1:MaxRound
    % if update batch by batch
    m1ScoreUpdated=-ones(size(m1Scores,1),1);
    for j=1:numNodes
        if m1Scores(j)==-1
            continue;
        end
        nodeID=allNodeIDs(j);        
        indexs1=find(Invs(:,1)==nodeID);
        indexs2=find(Invs(:,2)==nodeID);
        numLinks=length(indexs1)+length(indexs2);
        
        % brokenNeiNodeSet is the set of all neighboring broken nodeIDs and Score.
        brokenNeiNodeSet=[];
        countj=0;
        for ij=1:length(indexs1)
            neiNodeID=Invs(indexs1(ij),2);
            if StatuesInv(indexs1(ij))
                countj=countj+1;
                index_NodeinallNodeIDs=find(allNodeIDs==neiNodeID);
                m1Score_ij=m1Scores(index_NodeinallNodeIDs);
                brokenNeiNodeSet(countj,:)=[neiNodeID,m1Score_ij];
            end
        end
        for ij=1:length(indexs2)
            neiNodeID=Invs(indexs2(ij),1);
            if StatuesInv(indexs2(ij))
                countj=countj+1;
                index_NodeinallNodeIDs=find(allNodeIDs==neiNodeID);
                m1Score_ij=m1Scores(index_NodeinallNodeIDs);
                brokenNeiNodeSet(countj,:)=[neiNodeID,m1Score_ij];
            end
        end
        
        updatedm1Score_j=updateScore(m1Scores(j),numLinks,brokenNeiNodeSet);        
        % if update one by one
        m1Scores(j)=updatedm1Score_j;
        % if update batch by batch
%         m1ScoreUpdated(j)=updatedm1Score_j; 
    end

    % record scores and ranks
    % if update one by one
    m1ScoreUpdated=m1Scores;
    [SortedrScore,ind12]=sort(m1ScoreUpdated,'descend');
    RankedMetrics_i=allNodeIDs(ind12);
    scoreRecords(:,i+1)=m1ScoreUpdated;
    rankRecords(:,i+1)=RankedMetrics_i;
    
    % maintained the updated one as parent of next iteration
%     m1Scores=m1ScoreUpdated;
end


% mute out some broken links based on final m1Scores
% rule: if both m1scores of two nodes of one broken link is low than threshold, mute out the broken link.
tau_m1Score=0.15;
for i=1:numInv
    if StatuesInv(i)==1
        nodeIDy=Invs(i,1);
        nodeIDx=Invs(i,2);
        index_IDy_withinallNodeIDs=find(allNodeIDs==nodeIDy);
        index_IDx_withinallNodeIDs=find(allNodeIDs==nodeIDx);
        m1score_nodey=m1Scores(index_IDy_withinallNodeIDs);
        m1score_nodex=m1Scores(index_IDx_withinallNodeIDs);
        if m1score_nodey<tau_m1Score && m1score_nodex<tau_m1Score
            StatuesInv(i)=0;
        end
    end
end

% get m2Scores with final m1Scores and combine them together
m2Scores=-ones(numNodes,1);
for i=1:numNodes
    nodeID=allNodeIDs(i);
    indexs1=find(Invs(:,1)==nodeID);
    indexs2=find(Invs(:,2)==nodeID);
    numBrokenLinks=sum(StatuesInv(indexs1,:))+sum(StatuesInv(indexs2,:));
    if numBrokenLinks==0
        continue;
    end
    
    % get 1st-order neighoring nodes id with broken links
    neinodeIDs1=Invs(indexs1,:);
    Stats1=StatuesInv(indexs1,:);
    subindex1= Stats1==1;
    neibrokenodesIDs1=neinodeIDs1(subindex1,2);
    
    neinodeIDs2=Invs(indexs2,:);
    Stats2=StatuesInv(indexs2,:);
    subindex2= Stats2==1;
    neibrokenodesIDs2=neinodeIDs2(subindex2,1);
    neibrokennodesIDs=[neibrokenodesIDs1;neibrokenodesIDs2];
    
    % count how many links among BINN and how many are broken.
    countLinksBILs=0;
    countBrokenLinksBILs=0;
    numNeibrokennodesIDs=length(neibrokennodesIDs);
    if numNeibrokennodesIDs==0
        error('non consitent for numNeibrokennodesIDs');
    end
    for j=1:numNeibrokennodesIDs
        brokennodesID_j=neibrokennodesIDs(j);
        Indexs1_j=find(Invs(:,1)==brokennodesID_j);
        Indexs2_j=find(Invs(:,2)==brokennodesID_j);
        countLinksBILs=countLinksBILs+length(Indexs1_j)+length(Indexs2_j)-1;
        Index_nodej_withinAllnode=find(allNodeIDs==brokennodesID_j);
        if isempty(Index_nodej_withinAllnode)
            error('cannot find node in Allnode');
        end
        m1score_j=m1Scores(Index_nodej_withinAllnode);
        countBrokenLinksBILs=countBrokenLinksBILs+m1score_j*(length(Indexs1_j)+length(Indexs2_j)-1);
    end
    % compute modified m2Score, think about computing iteratively
    if countLinksBILs==0
        m2Scores(i)=0;
    else
        m2Scores(i)=1-countBrokenLinksBILs/countLinksBILs;
    end
    
end

mScores=m1Scores+m2Scores;

% scan all Invs and get rScore record
rScoreAllBrokenInvs=zeros(numInv,4);
count11=0;
for k=1:numInv
    if StatuesInv(k)==1
        nodeID1=Invs(k,1);
        nodeID2=Invs(k,2);
        index1=find(allNodeIDs==nodeID1);
        index2=find(allNodeIDs==nodeID2);
        mScore1=mScores(index1,1);
        mScore2=mScores(index2,1);
        rScoreNode1=mScore1/(mScore1+mScore2);
        rScoreNode2=mScore2/(mScore1+mScore2);
        count11=count11+1;
        rScoreAllBrokenInvs(count11,:)=[nodeID1,rScoreNode1,nodeID2,rScoreNode2];
    end
end
rScoreAllBrokenInvs=rScoreAllBrokenInvs(1:count11,:);

% crossing scan all Invs and all Nodes to get final rScore
finalrScores=-ones(numNodes,1);
for k=1:numNodes
    nodeID_k=allNodeIDs(k,1);
    Index1=find(rScoreAllBrokenInvs(:,1)==nodeID_k);
    rScoreRecord1=rScoreAllBrokenInvs(Index1,2);
    Index2=find(rScoreAllBrokenInvs(:,3)==nodeID_k);
    rScoreRecord2=rScoreAllBrokenInvs(Index2,4);
    rScoreRecord=[rScoreRecord1;rScoreRecord2];
    if ~isempty(rScoreRecord)
        finalrScores(k,1)=mean(rScoreRecord);
    end
end

[SortedrScore,ind]=sort(finalrScores,'descend');
% a list of indexs of metrics, sorted by rScore (from high to low)
RankedMetrics=allNodeIDs(ind);
% AbnScores: the rScore of metrics correponding to RankedMetrics
AbnScores=SortedrScore;

end











function updatedm1Score_j=updateScore(m1Scores_j,numLinks,brokenNeiNodeSet)

if m1Scores_j==-1
    error('original score is negative');
end
if size(brokenNeiNodeSet,1)>numLinks
    error('# of broken neighboring nodes is larger than # of all neighboring nodes');
end
temp=0;
for i=1:size(brokenNeiNodeSet,1)
    temp=temp+(1-brokenNeiNodeSet(i,2))*1;
end
if temp>numLinks
    error('number of broken links with backup is larger than number of all links');
end
updatedm1Score_j=temp/numLinks;


% enforce a rule to avoid updated m1score becoming to 0
% if updatedm1Score_j==0
%    updatedm1Score_j=m1Scores_j;
% end



end











