% main function

clear
clc
close all



warning off;



% [Invs,MNK,theta,testdata]=organize(series,attnames,invsfilename,testdatafilename);
% training series and testing series are already one-to-one mapped


TrainSeries=load('C:\siat\delivery\data\TrainSeries_demo-2009-9-27-1500-1749.mat');
TrainSeries_Attnames=load('C:\siat\delivery\data\TrainSeriesAttnames_demo-2009-9-27-1500-1749.mat');
TrainSeries=TrainSeries.series;
TrainSeries_Attnames=TrainSeries_Attnames.attnames;

InputInvTracking=load('C:\siat\delivery\data\InvTrackInput_demo-2009-9-27-1500-1749');
InputInvTracking=InputInvTracking.InputInvTracking;

% get abnormal series's IDs from all training series
IndexsAbnorSignals=[];countAbnor=0;
for i=1:size(TrainSeries,1)
    attName=TrainSeries_Attnames{i,1};
    checker_i=strfind(attName,'AP11');
    if ~isempty(checker_i)
        countAbnor=countAbnor+1;
        IndexsAbnorSignals(countAbnor,1)=i;
    end
end


Inv1=InputInvTracking.Invs;
Thetas=InputInvTracking.theta;
MNK=InputInvTracking.MNK;
testdata=InputInvTracking.testdata;

WholeTestData=testdata;




% believe: 1-138 samples are good, from 139th, some nodes becomes bad
FaultIndex=140;
OnesnapShot=testdata(:,FaultIndex);
Goodpart=TrainSeries;
testdata=[Goodpart,OnesnapShot];



[StatuesInv,Residuals]=InvTracking(Inv1,Thetas,MNK,testdata);


%% visualize the invariants networks(with broken links and abnormal nodes) before ranking
allNodeIDs=unique([Inv1(:,1),Inv1(:,2)]);
numNodes=length(allNodeIDs);
AdjaMatrix=zeros(numNodes,numNodes);
for i=1:size(Inv1,1)
    IDleft_i=Inv1(i,1);
    IDright_i=Inv1(i,2);
    Index4left=find(allNodeIDs==IDleft_i);
    Index4right=find(allNodeIDs==IDright_i);
    if StatuesInv(i)==0
        AdjaMatrix(Index4left,Index4right)=0.5;
        AdjaMatrix(Index4right,Index4left)=0.5;
    else
        AdjaMatrix(Index4left,Index4right)=1;
        AdjaMatrix(Index4right,Index4left)=1;
    end
end
randSeries4x=randperm(numNodes);
randSeries4y=randperm(numNodes);
xy=[randSeries4x',randSeries4y'];
A=sparse(AdjaMatrix);

IDsAbnorSignals=IndexsAbnorSignals;
vertexWeight=zeros(numNodes,1);
countAbnor_withNetworks=0;
for i=1:numNodes
    nodeID=allNodeIDs(i);
    if ~any(IDsAbnorSignals==nodeID)
        vertexWeight(i)=-1;
    else
        countAbnor_withNetworks=countAbnor_withNetworks+1;
        vertexWeight(i)=2;
    end
end
figure;
[he,hv]=wgPlot(A,xy,'vertexWeight',vertexWeight);

%% label nodes with att name
for i=1:countAbnor
    abnorID_i=IDsAbnorSignals(i);
    index_abnori_withinallNodes=find(allNodeIDs==abnorID_i);
    if isempty(index_abnori_withinallNodes)
        continue;
    end
    position_i=xy(index_abnori_withinallNodes,:);
    string_label=TrainSeries_Attnames{abnorID_i};
    text(position_i(1),position_i(2),string_label,'FontSize',8);
end




% get benchmark from inv networks
count_temp=0;
for i=1:countAbnor
    AbnorID=IndexsAbnorSignals(i);
    checker_i=find(allNodeIDs==AbnorID);
    if ~isempty(checker_i)
        count_temp=count_temp+1;
        rankedBenchmark(count_temp,1)=AbnorID;
    end
end
abnorDegreeBench=ones(countAbnor_withNetworks,1);



% plot out some series of testing data, which are related to AP11.
for i=1:count_temp
    IndexAbnor_i=rankedBenchmark(i);
    series_i_testing=WholeTestData(IndexAbnor_i,:);
    figure;
    plot((1:length(series_i_testing)),series_i_testing,'-cx');
    hold on;
    plot(139,series_i_testing(139),'-rx');
    attname_i=TrainSeries_Attnames{IndexAbnor_i};
    title(attname_i);
end



% check how many broken links are associated with benchmark node(AP11)
numTotalBrokenLinks=sum(StatuesInv);
numBrokenLinksAssoBenchmark=0;
for i=1:length(StatuesInv)
    if StatuesInv(i)==1
        PairNodeIDs=Inv1(i,:);
        if any(rankedBenchmark==PairNodeIDs(1)) || any(rankedBenchmark==PairNodeIDs(2))
            numBrokenLinksAssoBenchmark=numBrokenLinksAssoBenchmark+1;
        end
    end
end

disp('num of total links:' );disp(length(StatuesInv));
disp('num of broken links: ');disp(sum(StatuesInv));
disp('num of broken links associate with AP11-related nodes: ');disp(numBrokenLinksAssoBenchmark);disp(numBrokenLinksAssoBenchmark/numTotalBrokenLinks);
disp('numb of AP11-related nodes: ');disp(countAbnor);
disp('numb of AP11-related nodes within Inv networks: ');disp(countAbnor_withNetworks);






%% rank with different methods

[nRankedMetrics,nAbnScores,m1Scores,m2Scores,rScores]=RankMetric(StatuesInv,Inv1,Residuals,'nRank');
[ggRankedMetrics,ggAbnScores,ggscoreRecords,ggrankRecords,m1Scores,m2Scores,rScores]=MetricRankPlusPlus(StatuesInv,Inv1,Residuals);



% save top-k abnormal metrics ranked by algorithms
TopK=2*length(rankedBenchmark);
for i=1:TopK    
    nTopK{i}=TrainSeries_Attnames{nRankedMetrics(i)};
    ggTopK{i}=TrainSeries_Attnames{ggRankedMetrics(i)};
end
for i=1:TopK/2
    Benchmark{i}=TrainSeries_Attnames{rankedBenchmark(i)};
end
bechmarkANDdifferentTopK.Benchmark=Benchmark;
bechmarkANDdifferentTopK.nTopK=nTopK;
bechmarkANDdifferentTopK.ggTopK=ggTopK;
% save('D:\siat\python\matlabcode\rankmetric(realdata)\results\benchmarkANDdifferentTopK@144.mat','bechmarkANDdifferentTopK');


%% visualize the ranking of nodes based on the previous visualization
vertexWeight=zeros(numNodes,1);
for i=1:numNodes
    nodeID=allNodeIDs(i);
    index_within_rankedMetrics=find(ggRankedMetrics==nodeID);
    vertexWeight(i)=ggAbnScores(index_within_rankedMetrics);
end
figure;
[he,hv]=wgPlot(A,xy,'vertexWeight',vertexWeight);


%% label nodes with rank,various scores
NumAbnorSignal=countAbnor_withNetworks;
NumLabel=NumAbnorSignal+5;
for i=1:NumLabel
    nodeID_i=ggRankedMetrics(i);
    index_nodeID_i_within_allNodes=find(allNodeIDs==nodeID_i);
    position_i=xy(index_nodeID_i_within_allNodes,:);
    m1score_i=m1Scores(index_nodeID_i_within_allNodes);
    m2score_i=m2Scores(index_nodeID_i_within_allNodes);
    rscore_i=rScores(index_nodeID_i_within_allNodes);
    string1=num2str(m1score_i);
    string2=num2str(m2score_i);
    string3=num2str(rscore_i);
    string4=num2str(i);
    string_label=strcat('(',string4,')','m1sc:',string1,';m2sc:',string2,';rsc:',string3);
    text(position_i(1),position_i(2),string_label,'FontSize',8);
end







%% validate with various measurements, such as precision, recall, average precision, NDCG.

% draw precision-recall curve
time4xMax=2;
xMax=time4xMax*NumAbnorSignal;
nPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    nPreRec(i,:)=PrecisionRecall(rankedBenchmark,nRankedMetrics(1:i));
end
ggPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    ggPreRec(i,:)=PrecisionRecall(rankedBenchmark,ggRankedMetrics(1:i));
end

figure;
subplot(2,2,1); plot(1:xMax,nPreRec(:,1),'-r+');
subplot(2,2,2); plot(1:xMax,nPreRec(:,2),'--r+');
subplot(2,2,3); plot(1:xMax,ggPreRec(:,1),'-g+');
subplot(2,2,4); plot(1:xMax,ggPreRec(:,2),'--g+');








% validate ranking via nDCG
resultsNDCG=[];count12=0;
for i=1:2:length(rankedBenchmark)
    p=i;
    [NDCGn,DCGn]=NDCG(rankedBenchmark,abnorDegreeBench,nRankedMetrics,p);
    [NDCGgg,DCGgg]=NDCG(rankedBenchmark,abnorDegreeBench,ggRankedMetrics,p);
    count12=count12+1;
    resultsNDCG(:,count12)=[p,DCGgg,DCGn,NaN, NDCGgg,NDCGn]';
end
figure;
plot(1:2:length(rankedBenchmark),resultsNDCG(5,:),'-g+');hold on;
plot(1:2:length(rankedBenchmark),resultsNDCG(6,:),'-rs');hold on;

disp('done')






