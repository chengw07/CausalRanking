function [rankedBenchmark,abnorDegreeBench]=getAnomalyResiduals(Inv1, Thetas, IndexsAbnorSignals, SeriesExtend, GoodColumn)
% This function is to measure the anomly degree with residul

% Anomaly: a node is considered as anomaly if its related residuals at certain timestamp deviate from normal cases on average.
numInvs=size(Inv1,1);
NumPoints=size(SeriesExtend,2);

% first get residual in normal case
GoodPart=SeriesExtend(:,1:(NumPoints-1));
ResidualsGood=zeros(numInvs,size(GoodPart,2)-3);
for i=1:numInvs
    yIndex=Inv1(i,1);
    xIndex=Inv1(i,2);
    ys=GoodPart(yIndex,:);
    xs=GoodPart(xIndex,:);
    for j=1:(size(GoodPart,2)-3)
        y_j=ys(j+3);
        yhat_j=dot(Thetas{i,1},[ys(j+2),ys(j+1),ys(j),xs(j+3),xs(j+2),xs(j+1),1]');
        ResidualsGood(i,j)=y_j-yhat_j;
    end
end

% for each abnormal signal, get its average residual change
for i=1:length(IndexsAbnorSignals)
    AbnorSignalID=IndexsAbnorSignals(i);
    Indexs_i_l=find(Inv1(:,1)==AbnorSignalID);
    Indexs_i_r=find(Inv1(:,2)==AbnorSignalID);
    Indexs_i=[Indexs_i_l;Indexs_i_r];
    Count_4i=0;
    Sum_OverThresPercen=0;
    if isempty(Indexs_i)
        error('abnormal signal is not found in inv network');
    end
    for j=1:length(Indexs_i)
        Index_j_withinInv=Indexs_i(j);
        Residuals_j=ResidualsGood(Index_j_withinInv,:);
        autoThreshold=1.1*prctile(abs(Residuals_j),99.5);
        if autoThreshold==0
            error('Fitness Threshold is 0');
        end 
        
        theta_j=Thetas{Index_j_withinInv,1};
        if AbnorSignalID==Inv1(Index_j_withinInv,1)
            y_j=SeriesExtend(Inv1(Index_j_withinInv,1),end);
            xs_j=[SeriesExtend(Inv1(Index_j_withinInv,1),NumPoints-1),SeriesExtend(Inv1(Index_j_withinInv,1),NumPoints-2),SeriesExtend(Inv1(Index_j_withinInv,1),NumPoints-3),GoodColumn(Inv1(Index_j_withinInv,2),1),SeriesExtend(Inv1(Index_j_withinInv,2),NumPoints-1),SeriesExtend(Inv1(Index_j_withinInv,2),NumPoints-2),1]';
        else
            y_j=GoodColumn(Inv1(Index_j_withinInv,1),1);
            xs_j=[SeriesExtend(Inv1(Index_j_withinInv,1),NumPoints-1),SeriesExtend(Inv1(Index_j_withinInv,1),NumPoints-2),SeriesExtend(Inv1(Index_j_withinInv,1),NumPoints-3),SeriesExtend(Inv1(Index_j_withinInv,2),NumPoints),SeriesExtend(Inv1(Index_j_withinInv,2),NumPoints-1),SeriesExtend(Inv1(Index_j_withinInv,2),NumPoints-2),1]';
        end
        yhat_j=dot(theta_j,xs_j);
        residual_j=abs(yhat_j-y_j); 
        if residual_j-autoThreshold>0
            Count_4i=Count_4i+1;
            OverThresPercen=(residual_j-autoThreshold)/autoThreshold;
            Sum_OverThresPercen=Sum_OverThresPercen+OverThresPercen;
        end
    end
    if Count_4i>0
        Average_OverThresPercen=Sum_OverThresPercen/Count_4i;
    else
        Average_OverThresPercen=0;
    end    
    AnomalyDegree_Residual(i,1)=Average_OverThresPercen;
end

[SortedAnomalyDegree,Indss]=sort(AnomalyDegree_Residual,'descend');
rankedBenchmark=IndexsAbnorSignals(Indss);
abnorDegreeBench=SortedAnomalyDegree;



end