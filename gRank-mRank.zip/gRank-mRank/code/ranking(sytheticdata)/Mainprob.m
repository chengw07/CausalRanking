% main function
% use ave of rscores as finall score and incoporate the uncertainty of broken invariants.
clear
clc
close all



warning off;
data_csv=dlmread('C:\siat\delivery\data\synthetics2000.csv');
Threshold=[0.5,0.7];
Series=data_csv(1:200,:);

%% increase the length of series
numSamples=size(data_csv,2);
times=1;
ExtendSeries=zeros(size(Series,1),times*numSamples);
for i=1:times
    randS=randperm(numSamples);
    ExtendSeries(:,((i-1)*numSamples+1):i*numSamples)=Series(:,randS);
end
Series=ExtendSeries;


%% filter out constant signal
Temp=[];
Count=0;
for i=1:size(Series,1)
    if var(Series(i,:))~=0
        Count = Count +1;
        Temp(Count,:)=Series(i,:);
    end
end

Series=Temp;
NumSeries=size(Series,1);


%% get inital index and count0
RemainedListAfterPrevious=zeros((NumSeries*NumSeries-NumSeries)/2,2);
Count0=0;
for i=1:NumSeries
    for j=(i+1):NumSeries
        Count0=Count0+1;
        RemainedListAfterPrevious(Count0,:)=[i,j];
    end
end


%% scratch searching
tstart=tic;
[Inv1, Percentage1, Thetas]=Scratch(Series, RemainedListAfterPrevious, Count0, Threshold);
t1=toc(tstart);

disp('done');

% generate extended series for all series
NumExtendedSamples=1;
GoodColum=Series(:,end);

%% generate testing signal with different abnormly
IndexsY=unique(Inv1(:,1));
AbnorPercenSignal=0.15;
RandomSeries=randperm(length(IndexsY));RandomSeries=RandomSeries';
IndexsAbnorSignals=IndexsY(RandomSeries(1:floor(AbnorPercenSignal*length(IndexsY))));
NumAbnorSignal=length(IndexsAbnorSignals);
SyAbnorDegree=1+3*rand(NumAbnorSignal,1);
% directly change the last sample abnormally based on the original "normal" value
BadColum=GoodColum;
for i=1:NumAbnorSignal
    NormalVal=GoodColum(IndexsAbnorSignals(i),1);
    BadColum(IndexsAbnorSignals(i),1)=SyAbnorDegree(i)*NormalVal;
end


[SortedAbnorDegree,Ind11]=sort(SyAbnorDegree,'descend');

rankedBenchmark_SignalInt=IndexsAbnorSignals(Ind11,1);
abnorDegreeBench_SignalInt=SortedAbnorDegree;

% the last column of SeriesExtend is injected anomaly, all the rest are from training set for inv search.
OnesnapShot=BadColum;
Goodpart=Series;
SeriesExtend=[Goodpart,OnesnapShot];

% define and measure anomaly of a node based on the changing degree of its related residuals compared with normal situation.
[rankedBenchmarkRes,abnorDegreeBenchRes]=getAnomalyResiduals(Inv1, Thetas, IndexsAbnorSignals, SeriesExtend, GoodColum);
rankedBenchmarkInt=rankedBenchmark_SignalInt;abnorDegreeBenchInt=abnorDegreeBench_SignalInt;
[StatuesInv,Residuals]=InvTracking(Inv1,Thetas,SeriesExtend);


%% visualize the invariants networks(with broken links and abnormal nodes) before ranking
allNodeIDs=unique([Inv1(:,1),Inv1(:,2)]);
numNodes=length(allNodeIDs);
AdjaMatrix=zeros(numNodes,numNodes);
for i=1:size(Inv1,1)
    IDleft_i=Inv1(i,1);
    IDright_i=Inv1(i,2);
    Index4left=find(allNodeIDs==IDleft_i);
    Index4right=find(allNodeIDs==IDright_i);
    if StatuesInv(i)==0
        AdjaMatrix(Index4left,Index4right)=0.5;
        AdjaMatrix(Index4right,Index4left)=0.5;
    else
        AdjaMatrix(Index4left,Index4right)=1;
        AdjaMatrix(Index4right,Index4left)=1;
    end
end
randSeries4x=randperm(numNodes);
randSeries4y=randperm(numNodes);
xy=[randSeries4x',randSeries4y'];
A=sparse(AdjaMatrix);
IDsAbnorSignals=IndexsAbnorSignals;
vertexWeight=zeros(numNodes,1);
for i=1:numNodes
    nodeID=allNodeIDs(i);
    if ~any(rankedBenchmarkInt==nodeID)
        vertexWeight(i)=-1;
    else
        index_i=find(rankedBenchmarkInt==nodeID);
        vertexWeight(i)=abnorDegreeBenchInt(index_i);
    end
end
figure;
[he,hv]=wgPlot(A,xy);
[he,hv]=wgPlot(A,xy,'vertexWeight',vertexWeight);

%% label nodes with abnormal degree
NumLabel=NumAbnorSignal+1;
[rankedVertexWeight,index4vertex]=sort(vertexWeight,'descend');
NumLabel=min([NumLabel,length(vertexWeight)]);
for i=1:NumLabel
    position_i=xy(index4vertex(i),:);
    string_label=num2str(rankedVertexWeight(i));
    text(position_i(1),position_i(2),string_label,'FontSize',8);
end


%% rank with different methods

[mRankedMetrics,mAbnScores]=ProbRankMetric(StatuesInv,Inv1,Residuals,'mRank');
[nRankedMetrics,nAbnScores]=ProbRankMetric(StatuesInv,Inv1,Residuals,'nRank');
[ggRankedMetrics,ggAbnScores,ggscoreRecords,ggrankRecords,m1Scores,m2Scores,rScores]=MetricRankPlusPlusPro(StatuesInv,Inv1,Residuals);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%--------------------step-by-step(progressively) mute out some noisy broken links based on thresholding technique---------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%% visualize the ranking of nodes based on the previous visualization
vertexWeight=zeros(numNodes,1);
for i=1:numNodes
    nodeID=allNodeIDs(i);
    index_within_rankedMetrics=find(ggRankedMetrics==nodeID);
    vertexWeight(i)=ggAbnScores(index_within_rankedMetrics);
end
figure;
[he,hv]=wgPlot(A,xy,'vertexWeight',vertexWeight);
%% label nodes with rank,various scores
NumLabel=NumAbnorSignal+5;
for i=1:NumLabel
    nodeID_i=ggRankedMetrics(i);
    index_nodeID_i_within_allNodes=find(allNodeIDs==nodeID_i);
    position_i=xy(index_nodeID_i_within_allNodes,:);
    m1score_i=m1Scores(index_nodeID_i_within_allNodes);
    m2score_i=m2Scores(index_nodeID_i_within_allNodes);
    rscore_i=rScores(index_nodeID_i_within_allNodes);
    string1=num2str(m1score_i);
    string2=num2str(m2score_i);
    string3=num2str(rscore_i);
    string4=num2str(i);
    string_label=strcat('(',string4,')','m1sc:',string1,';m2sc:',string2,';rsc:',string3);
    text(position_i(1),position_i(2),string_label,'FontSize',8);
end

%% visualize the ranking of nodes based on the previous visualization
vertexWeight=zeros(numNodes,1);
for i=1:numNodes
    nodeID=allNodeIDs(i);
    index_within_rankedMetrics=find(nRankedMetrics==nodeID);
    vertexWeight(i)=nAbnScores(index_within_rankedMetrics);
end
figure;
[he,hv]=wgPlot(A,xy,'vertexWeight',vertexWeight);
%% label nodes with rank,various scores
NumLabel=NumAbnorSignal+5;
for i=1:NumLabel
    nodeID_i=nRankedMetrics(i);
    index_nodeID_i_within_allNodes=find(allNodeIDs==nodeID_i);
    position_i=xy(index_nodeID_i_within_allNodes,:);
    m1score_i=m1Scores(index_nodeID_i_within_allNodes);
    m2score_i=m2Scores(index_nodeID_i_within_allNodes);
    rscore_i=rScores(index_nodeID_i_within_allNodes);
    string1=num2str(m1score_i);
    string2=num2str(m2score_i);
    string3=num2str(rscore_i);
    string4=num2str(i);
    string_label=strcat('(',string4,')','m1sc:',string1,';m2sc:',string2,';rsc:',string3);
    text(position_i(1),position_i(2),string_label,'FontSize',8);
end

%% validate with Intensity-based benchmark

% draw precision-recall curve
time4xMax=2;
xMax=time4xMax*NumAbnorSignal;
mPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    mPreRec(i,:)=PrecisionRecall(rankedBenchmarkInt,mRankedMetrics(1:i));
end
nPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    nPreRec(i,:)=PrecisionRecall(rankedBenchmarkInt,nRankedMetrics(1:i));
end
ggPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    ggPreRec(i,:)=PrecisionRecall(rankedBenchmarkInt,ggRankedMetrics(1:i));
end


figure;
plot(1:xMax,mPreRec(:,1),'-b*'); hold on;
plot(1:xMax,nPreRec(:,1),'-r+');
hold on; plot(1:xMax,ggPreRec(:,1),'-gs');
figure;
plot(1:xMax,mPreRec(:,2),'--b*');hold on
plot(1:xMax,nPreRec(:,2),'--r+');
hold on; plot(1:xMax,ggPreRec(:,2),'--gs');



% validate ranking via nDCG
resultsNDCG=[];count12=0;
for i=1:2:length(rankedBenchmarkInt)
    p=i;
    [NDCGm,DCGm]=NDCG(rankedBenchmarkInt,abnorDegreeBenchInt,mRankedMetrics,p);
    [NDCGn,DCGn]=NDCG(rankedBenchmarkInt,abnorDegreeBenchInt,nRankedMetrics,p);
    [NDCGgg,DCGgg]=NDCG(rankedBenchmarkInt,abnorDegreeBenchInt,ggRankedMetrics,p);
    count12=count12+1;
    resultsNDCGInt(:,count12)=[p,DCGgg,DCGn,DCGm,NaN, NDCGgg,NDCGn,NDCGm]';
end
figure;
plot(1:2:length(rankedBenchmarkInt),resultsNDCGInt(6,:),'-gs');hold on;
plot(1:2:length(rankedBenchmarkInt),resultsNDCGInt(7,:),'-r+');hold on;
plot(1:2:length(rankedBenchmarkInt),resultsNDCGInt(8,:),'-b*');hold on;






%% validate with residual-based benchmark

% draw precision-recall curve
time4xMax=2;
xMax=time4xMax*NumAbnorSignal;
mPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    mPreRec(i,:)=PrecisionRecall(rankedBenchmarkRes,mRankedMetrics(1:i));
end
nPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    nPreRec(i,:)=PrecisionRecall(rankedBenchmarkRes,nRankedMetrics(1:i));
end
ggPreRec=zeros(time4xMax*NumAbnorSignal,2);
for i=1:xMax
    ggPreRec(i,:)=PrecisionRecall(rankedBenchmarkRes,ggRankedMetrics(1:i));
end


figure;
plot(1:xMax,mPreRec(:,1),'-b*'); hold on;
plot(1:xMax,nPreRec(:,1),'-r+');
hold on; plot(1:xMax,ggPreRec(:,1),'-gs');
figure;
plot(1:xMax,mPreRec(:,2),'--b*');hold on
plot(1:xMax,nPreRec(:,2),'--r+');
hold on; plot(1:xMax,ggPreRec(:,2),'--gs');


% validate ranking via nDCG
resultsNDCG=[];count12=0;
for i=1:2:length(rankedBenchmarkRes)
    p=i;
    [NDCGm,DCGm]=NDCG(rankedBenchmarkRes,abnorDegreeBenchRes,mRankedMetrics,p);
    [NDCGn,DCGn]=NDCG(rankedBenchmarkRes,abnorDegreeBenchRes,nRankedMetrics,p);
    [NDCGgg,DCGgg]=NDCG(rankedBenchmarkRes,abnorDegreeBenchRes,ggRankedMetrics,p);
    count12=count12+1;
    resultsNDCGRes(:,count12)=[p,DCGgg,DCGn,DCGm,NaN, NDCGgg,NDCGn,NDCGm]';
end
figure;
plot(1:2:length(rankedBenchmarkRes),resultsNDCGRes(6,:),'-gs');hold on;
plot(1:2:length(rankedBenchmarkRes),resultsNDCGRes(7,:),'-r+');hold on;
plot(1:2:length(rankedBenchmarkRes),resultsNDCGRes(8,:),'-b*');hold on;




disp('done')






