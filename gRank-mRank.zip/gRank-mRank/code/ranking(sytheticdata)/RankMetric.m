function [RankedMetrics,AbnScores,m1Scores,m2Scores,finalrScores]=RankMetric(StatuesInv,Invs,Residuals,ind)
% This function is to rank the metric with average of rscores as final
% score

% Ind: the indicator of different methods. "mRank" is the baseline
% algorithm; "nRank" is the algorithm I

if strcmp(ind,'mRank')
    
    
numInv=size(Invs,1);
numResiduls=size(Residuals,2);


% get all nodes
% nodeID is the index of time series
allNodeIDs=unique([Invs(:,1),Invs(:,2)]);
numNodes=length(allNodeIDs);

% m1Scores is the m1 score
% -1 indicates no associated broken links
m1Scores=-ones(numNodes,1);
m2Scores=-ones(numNodes,1);

for i=1:numNodes
    nodeID=allNodeIDs(i);
    indexs1=find(Invs(:,1)==nodeID);
    indexs2=find(Invs(:,2)==nodeID);
    numLinks=length(indexs1)+length(indexs2);
    numBrokenLinks=sum(StatuesInv(indexs1,:))+sum(StatuesInv(indexs2,:));
    if numBrokenLinks==0
        continue;
    end
    m1Scores(i)=numBrokenLinks/numLinks;
   
    % get 1st-order neighoring nodes id with broken links
    neinodeIDs1=Invs(indexs1,:);
    Stats1=StatuesInv(indexs1,:);
    subindex1=find(Stats1==1);
    neibrokenodesIDs1=neinodeIDs1(subindex1,2);
    
    neinodeIDs2=Invs(indexs2,:);
    Stats2=StatuesInv(indexs2,:);
    subindex2=find(Stats2==1);
    neibrokenodesIDs2=neinodeIDs2(subindex2,1);
    
    neibrokennodesIDs=[neibrokenodesIDs1;neibrokenodesIDs2];
    countLinksBINN=0;
    countBrokenLinksBINN=0;
    
    % count how many links among BINN and how many are broken.
    for j=1:numInv
        nodeIDs=Invs(j,:);
        if any(neibrokennodesIDs==nodeIDs(1)) && any(neibrokennodesIDs==nodeIDs(2))
            countLinksBINN=countLinksBINN+1;
            if StatuesInv(j)==1
                countBrokenLinksBINN=countBrokenLinksBINN+1;
            end
        end
    end
    
    if countLinksBINN==0
        m2Scores(i)=0;
    else
        m2Scores(i)=1-countBrokenLinksBINN/countLinksBINN;
    end
    
end

mScores=m1Scores+m2Scores;

% scan all Invs and get rScore record
rScoreAllBrokenInvs=zeros(numInv,4);
count11=0;
for k=1:numInv
    if StatuesInv(k)==1
        nodeID1=Invs(k,1);
        nodeID2=Invs(k,2);
        index1=find(allNodeIDs==nodeID1);
        index2=find(allNodeIDs==nodeID2);
        mScore1=mScores(index1,1);
        mScore2=mScores(index2,1);
        rScoreNode1=mScore1/(mScore1+mScore2);
        rScoreNode2=mScore2/(mScore1+mScore2);
        count11=count11+1;
        rScoreAllBrokenInvs(count11,:)=[nodeID1,rScoreNode1,nodeID2,rScoreNode2];
    end
end
rScoreAllBrokenInvs=rScoreAllBrokenInvs(1:count11,:);

% crossing scan all Invs and all Nodes to get final rScore
finalrScores=-ones(numNodes,1);
for k=1:numNodes
    nodeID_k=allNodeIDs(k,1);
    Index1=find(rScoreAllBrokenInvs(:,1)==nodeID_k);
    rScoreRecord1=rScoreAllBrokenInvs(Index1,2);
    Index2=find(rScoreAllBrokenInvs(:,3)==nodeID_k);
    rScoreRecord2=rScoreAllBrokenInvs(Index2,4);
    rScoreRecord=[rScoreRecord1;rScoreRecord2];
    if ~isempty(rScoreRecord)
        finalrScores(k,1)=mean(rScoreRecord);
    end
end





elseif strcmp(ind,'nRank')

numInv=size(Invs,1);
numResiduls=size(Residuals,2);


% get all nodes
% nodeID is the index of time series
allNodeIDs=unique([Invs(:,1),Invs(:,2)]);
numNodes=length(allNodeIDs);

% m1Scores is the m1 score
% -1 indicates no associated broken links
m1Scores=-ones(numNodes,1);
m2Scores=-ones(numNodes,1);

for i=1:numNodes
    nodeID=allNodeIDs(i);
    indexs1=find(Invs(:,1)==nodeID);
    indexs2=find(Invs(:,2)==nodeID);
    numLinks=length(indexs1)+length(indexs2);
    numBrokenLinks=sum(StatuesInv(indexs1,:))+sum(StatuesInv(indexs2,:));
    if numBrokenLinks==0
        continue;
    end
    m1Scores(i)=numBrokenLinks/numLinks;
   
    % get 1st-order neighoring nodes id with broken links
    neinodeIDs1=Invs(indexs1,:);
    Stats1=StatuesInv(indexs1,:);
    subindex1= Stats1==1;
    neibrokenodesIDs1=neinodeIDs1(subindex1,2);
    
    neinodeIDs2=Invs(indexs2,:);
    Stats2=StatuesInv(indexs2,:);
    subindex2= Stats2==1;
    neibrokenodesIDs2=neinodeIDs2(subindex2,1);
    neibrokennodesIDs=[neibrokenodesIDs1;neibrokenodesIDs2];
    
    % count how many links among BINN and how many are broken.
    countLinksBILs=0;
    countBrokenLinksBILs=0;
    numNeibrokennodesIDs=length(neibrokennodesIDs);
    for j=1:numNeibrokennodesIDs
        brokennodesID_j=neibrokennodesIDs(j);
        Indexs1_j=find(Invs(:,1)==brokennodesID_j);
        BrokenNum1=sum(StatuesInv(Indexs1_j,1));
        Indexs2_j=find(Invs(:,2)==brokennodesID_j);
        BrokenNum2=sum(StatuesInv(Indexs2_j,1));
        countLinksBILs=countLinksBILs+length(Indexs1_j)+length(Indexs2_j)-1;
        countBrokenLinksBILs=countBrokenLinksBILs+BrokenNum1+BrokenNum2-1;
    end
    % compute modified m2Score, think about computing iteratively
    if countLinksBILs==0
        m2Scores(i)=0;
    else
        m2Scores(i)=1-countBrokenLinksBILs/countLinksBILs;
    end
end

mScores=m1Scores+m2Scores;

% scan all Invs and get rScore record
rScoreAllBrokenInvs=zeros(numInv,4);
count11=0;
for k=1:numInv
    if StatuesInv(k)==1
        nodeID1=Invs(k,1);
        nodeID2=Invs(k,2);
        index1= allNodeIDs==nodeID1;
        index2= allNodeIDs==nodeID2;
        mScore1=mScores(index1,1);
        mScore2=mScores(index2,1);
        rScoreNode1=mScore1/(mScore1+mScore2);
        rScoreNode2=mScore2/(mScore1+mScore2);
        count11=count11+1;
        rScoreAllBrokenInvs(count11,:)=[nodeID1,rScoreNode1,nodeID2,rScoreNode2];
    end
end
rScoreAllBrokenInvs=rScoreAllBrokenInvs(1:count11,:);


% crossing scan all Invs and all Nodes to get final rScore
finalrScores=-ones(numNodes,1);
for k=1:numNodes
    nodeID_k=allNodeIDs(k,1);
    Index1= rScoreAllBrokenInvs(:,1)==nodeID_k;
    rScoreRecord1=rScoreAllBrokenInvs(Index1,2);
    Index2= rScoreAllBrokenInvs(:,3)==nodeID_k;
    rScoreRecord2=rScoreAllBrokenInvs(Index2,4);
    rScoreRecord=[rScoreRecord1;rScoreRecord2];
    if ~isempty(rScoreRecord)
        finalrScores(k,1)=mean(rScoreRecord);
    end
end
    
end



[SortedrScore,ind]=sort(finalrScores,'descend');
% a list of indexs of metrics, sorted by rScore (from high to low)
RankedMetrics=allNodeIDs(ind);
% AbnScores: the rScore of metrics correponding to RankedMetrics
AbnScores=SortedrScore;






end