function [StatuesInv,Residuals]=InvTracking(Inv1,Thetas,SeriesExtend)
% This function to track the inv networks and get a state of inv networks at certain timestamp.

% The simutanous changing of two metrics holding an invariant may (with small possibility) lead to that the invariant happens to be not broken.

% Inv1: [i,j], i: index of y, j: index of x
% Thetas: the parameters of arx model:[y(t-1),y(t-2),y(t-3),x(t),x(t-1),x(t-2),1]
% SeriesExtend(with the same number of series as the original series): the last sample of each series is abnormal
% Residuals: all residulas are returned
% StatuesInv: 0 nonbroken, 1 broken

numInvs=size(Inv1,1);
%k=0;
Residuals=zeros(numInvs,size(SeriesExtend,2)-3);

for i=1:numInvs
    yIndex=Inv1(i,1);
    xIndex=Inv1(i,2);
    ys=SeriesExtend(yIndex,:);
    xs=SeriesExtend(xIndex,:);
    for j=1:(size(SeriesExtend,2)-3)
        y_j=ys(j+3);
        yhat_j=dot(Thetas{i,1},[ys(j+2),ys(j+1),ys(j),xs(j+3),xs(j+2),xs(j+1),1]');
        Residuals(i,j)=y_j-yhat_j;
    end
end

StatuesInv=zeros(numInvs,1);
numAllResi=size(Residuals,2);
for i=1:numInvs
    residualstrain=Residuals(i,1:(numAllResi-1));
    autoThreshold=1.1*prctile(abs(residualstrain),99.5);
    if abs(Residuals(i,end))>autoThreshold
        StatuesInv(i,1)=1;
    end
end





















end