data folder: all data sets used in the code folder



code folder: 
            pruning folder: upbound-based pruning
            ranking(realdata) folder: 3 different ranking algorithms tested on a real-world data with root cause information
            ranking(sytheticdata) folder: 3 different ranking algorithms tested on sythetic data sets.

To run the code, pls open the Main or Main** matlab file. Change the directory for data load, then you can run all code