import os
import numpy as np
import time
import copy
from xml.etree.ElementTree import *
from configobj import ConfigObj

class MRF:
    def __init__(self, invxml, bkxml=None):
        # list of metrics
        self.mets = []
        # list of invariants
        self.invs = []
        # list of anomaly scores
        self.fitness = []
        # list of broken invariants
        self.broken_invs = []
        # list of sensor anomaly scores
        self.a_scores = []
        # list of used invariants as links
        self.usedlinks = []

        self.extractFromXML(invxml)

        # normal/abnormal messages for each direction of edges
        self.messages = self.init_messages()

        self.mrf = None

        if bkxml != None:
            self.importBrokenInvs(bkxml)
            self.computeScore(useNeighbor=True)

    # initialize data and smoothness costs
    def init_costs(self,unbroken=False):
        self.computeScore()
        # propagation matrix
        self.PM = self.initPM(0.05, 0.45,unbroken=unbroken)
        self.datacost = np.array([np.ones(len(self.a_scores)) - np.array(self.a_scores), np.array(self.a_scores)])

    # initialize messages with all one
    def init_messages(self):
        n_mets = len(self.mets)
        messages = np.ones([2,n_mets,n_mets])
        return messages

    # initialize the propagation matrix (PM)
    def initPM(self,e0, e1,unbroken=False):
        PM = np.array([[e0, 1-e0], [1-e1, e1]])
        if unbroken:
            return PM.transpose()
        else:
            return PM

    # update messages in sum-product manner
    def update_messages(self):
        messages = copy.deepcopy(self.messages)
        #messages = self.messages
        for met_s in self.mets:
            for met_d in self.mets:
                if (met_s, met_d) in self.usedlinks or (met_d, met_s) in self.usedlinks:
                    s_id = self.mets.index(met_s)
                    d_id = self.mets.index(met_d)

                    neighbors_wo_d = self.get_neighbors(met_s)
                    neighbors_wo_d.remove(d_id)

                    msg_0 = np.sum(self.datacost[:, s_id] * self.PM[:,0] * np.prod(self.messages[:,neighbors_wo_d,d_id]))
                    msg_1 = np.sum(self.datacost[:, s_id] * self.PM[:,1] * np.prod(self.messages[:,neighbors_wo_d,d_id]))
                    messages[0,s_id,d_id] = msg_0
                    messages[1,s_id,d_id] = msg_1
        self.messages = messages / np.sum(messages,0)

    # calculate beliefs
    def compute_belief(self):
        belief = np.zeros([2,len(self.mets)])
        for met in self.mets:
            m_id = self.mets.index(met)
            neighbors = self.get_neighbors(met)
            belief[0, m_id] = self.datacost[0, m_id] * np.prod(self.messages[0,neighbors,m_id])
            belief[1, m_id] = self.datacost[1, m_id] * np.prod(self.messages[1,neighbors,m_id])
        belief = belief/np.sum(belief,0)
        return belief

    # run LPB algorithm
    def run_LBP(self, links=None, maxIter=10):
        if links == 'unbroken':
            self.init_costs(unbroken=True)
            self.usedlinks=list(set(self.invs)-set(self.broken_invs))
        else:
            self.init_costs(unbroken=False)
            self.usedlinks=self.broken_invs
        start = time.time()
        for i in np.arange(maxIter):
            self.update_messages()
        belief = self.compute_belief()
        elapsed = time.time() - start
        return belief, elapsed

    # show ranking results
    def showRank(self, outpath=None):
        belief = self.compute_belief()
        metrics = self.mets
        sorted_ind = np.argsort(belief[1,:])[-1::-1]
        print('Ranking Results:')
        print('-------------------------------------------------------------------')
        if outpath!=None:
            path = os.path.join('./', outpath)
            fp = open(path,'w')
            fp.write('Name,belief,org. score\n')
        print('Name,belief,org. score')
        for ind in sorted_ind:
            met = metrics[ind]
            b = belief[1,ind]
            org_ind = self.mets.index(met)
            org_score = self.a_scores[org_ind]
            line = '%s,%f,%f' % (met,b,org_score)
            print(line)
            if outpath!=None:
                fp.write('%s\n'%line)
        print('-------------------------------------------------------------------')
        if outpath!=None:
            fp.close()

    # get neighbor (connected) metrics with input metric
    def get_neighbors(self, metric):
        neighbors = [brk[abs(1-brk.index(metric))] for brk in self.usedlinks if metric in brk]
        return [self.mets.index(n) for n in neighbors]

    # extract invariant network from .inv.xml file
    def extractFromXML(self, xmlfile):
        tree = parse(xmlfile)
        root = tree.getroot()
        mets = []
        invs = []
        fitness = []
        for inv in root.findall('Invariant'):
            uName = inv.find('uName').text
            yName = inv.find('yName').text
            mets.append(uName)
            mets.append(yName)
            invs.append((uName, yName))
            fitness.append((float)(inv.find('fitness').text))

        mets = list(set(mets))
        mets.sort()
        self.mets = mets
        self.invs = invs
        self.fitness = fitness

    # extract broken invariants from anomaly information which can obtained by AnomalyChartViewer
    def importBrokenInvs(self, bkxml):
        tree = parse(bkxml)
        inv_root = tree.getroot()
        broken_invs = []
        for inv in inv_root.findall('Invariant'):
            significance = (float)(inv.find('significance').text)
            if significance > 1.1:
                uName = inv.find('uName').text
                yName = inv.find('yName').text
                broken_invs.append((uName, yName))
        self.broken_invs = broken_invs

    # calculating scores for each nodes
    def computeScore(self, useNeighbor=True):
        a_scores = []
        w = 0.5
        for metric in self.mets:
            nI = len([inv for inv in self.invs if metric in inv])
            nB = len([brk for brk in self.broken_invs if metric in brk])
            nodeScore = nB/nI
            neighborScore = 0
            if useNeighbor:
                BINN = [brk[abs(1-brk.index(metric))] for brk in self.broken_invs if metric in brk]
                nInvs = 0
                nBrks = 0
                for BINN_ in BINN:
                    nInvs = nInvs + len([inv for inv in self.invs if BINN_ in inv and inv[abs(1-inv.index(BINN_))] in BINN])
                    nBrks = nBrks + len([brk for brk in self.broken_invs if BINN_ in brk and brk[abs(1-brk.index(BINN_))] in BINN])
                if nInvs > 0:
                    neighborScore = 1-nBrks/nInvs
            a_scores.append(w*nodeScore+(1-w)*neighborScore)
        self.a_scores = a_scores

class MRFConfig:
    def __init__(self, cfgpath='./mrf_conf.ini'):
        self.cfg = ConfigObj(cfgpath)
        pds = self.cfg['MRFConfig']
        self.casename = pds['CaseName']
        self.inputdir = pds['InputDirectly']
        self.outputdir = pds['OutputDirectly']
        self.invfile = pds['InvariantFile']
        self.brokenfile = pds['BrokenData']
        self.links = pds['Links']


def run_experiments():
    conf = MRFConfig()
    invpath = os.path.join(conf.inputdir,conf.invfile)
    brkpath = os.path.join(conf.inputdir,conf.brokenfile)
    print('Initializing MRF...')
    mrf = MRF(invpath, brkpath)
    #mrf = MRF('./JX/mp1-cut1-BASE_MFPF_f0.3_0.5_MORCL_xM.inv.xml','./JX/mp1-cut1-BASE_MFPF_f0.3_0.5_MORCL_xM.as.xml')
    for mode in conf.links:
        print('Running LBP in %s setting...' % mode)
        call = 'mrf.run_LBP(links=\'%s\')' % mode
        dum, elapsed = eval(call)
        if not os.path.isdir(conf.outputdir):
            os.mkdir(conf.outputdir)
        outpath = os.path.join(conf.outputdir, 'LBP_%s_%s.csv' % (mode, conf.casename))
        mrf.showRank(outpath=outpath)
        print('Finished. Elapsed time = %f [sec].' % elapsed)
    print('Done.')

if __name__ == '__main__':
    run_experiments()
